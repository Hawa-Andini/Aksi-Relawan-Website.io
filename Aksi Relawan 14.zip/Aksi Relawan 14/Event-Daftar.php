<?php
session_start();

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
} else {
    $username = null; 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .bold-text {
            font-weight: bold;
        }
        .footer { 
            background-color: #333; 
            color: white; 
            text-align: center; 
            padding: 1rem; 
            position: relative; 
            width: 100%; 
            bottom: 0; 
        }
        main {
            padding-bottom: 3rem; 
        }
        .profile-icon {
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<header class="bg-danger text-white text-center py-3">
    <h1>Aksi Relawan</h1>
    <p>Bersama Membangun Negeri dengan Aksi Nyata</p>
</header>

<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="images/logo.jpg" alt="Logo Aksi Relawan" style="width: 40px;" class="rounded-circle">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a class="nav-link" href="HomePage.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="Event-Halaman Lain.php">Event</a></li>
                <li class="nav-item"><a class="nav-link" href="Donasi.php">Donasi</a></li>
                <li class="nav-item"><a class="nav-link" href="Daftar_Dokumentasi.php">Dokumentasi Event</a></li>
                <li class="nav-item"><a class="nav-link" href="Contact Us.php">Contact Us</a></li>
                <li class="nav-item"><a class="nav-link" href="About Us.php">About Us</a></li>
            </ul>
            <div class="dropdown">
                <div class="profile-icon dropdown-toggle" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo htmlspecialchars($username ?? '?'); ?>
                </div>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                    <?php if ($username): ?>
                        <li><a class="dropdown-item" href="Dashboard(User).php">Dashboard</a></li>
                        <li><a class="dropdown-item" href="logout.php">Keluar</a></li>
                    <?php else: ?>
                        <li><a class="dropdown-item" href="login.php">Login</a></li>
                        <li><a class="dropdown-item" href="buat_akun.php">Sign Up</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</nav>

<?php
include "koneksi.php";

if (isset($_GET['event_name'])) {
    $event_name = $_GET['event_name'];
} else {
    echo "<div class='alert alert-danger text-center'>Event name is not set in the URL.</div>";
    exit;
}

$stmt = $koneksi->prepare("SELECT * FROM tambah_event WHERE event_name = ?");
$stmt->bind_param("s", $event_name);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
?>
<div class="container my-5">
    <div class="row">
        <div class="col-lg-8 mb-4">
            <div class="card overflow-auto" style="max-height: 600px;">
                <img src="Images/<?php echo $row['event_image']; ?>" class="card-img-top" alt="Event Image">
                <div class="card-body">
                    <p style="text-align: justify;"><?php echo $row['description']; ?></p>
                    <h5>Detail Aktivitas</h5>
                    <p><?php echo $row['activity']; ?></p>
                    <h5>Pekerjaan</h5>
                    <ul>
                        <?php
                        $jobs = explode("\n", $row['job']); 
                        foreach ($jobs as $job) {
                            echo "<li>" . htmlspecialchars($job) . "</li>";
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div>


        <div class="col-lg-4">
            <div class="card p-3 mb-3">
                <h1 class="bold-text"><?php echo htmlspecialchars($event_name); ?></h1>
                <p class="fs-6">
                    <i class="fas fa-calendar-alt"></i>
                    <?php 
                    $event_date = $row['event_date']; 
                    $event_time = $row['event_time']; 
                    $event_timestamp = strtotime($event_date . " " . $event_time); 

                    $days = [
                        'Sunday' => 'Minggu',
                        'Monday' => 'Senin',
                        'Tuesday' => 'Selasa',
                        'Wednesday' => 'Rabu',
                        'Thursday' => 'Kamis',
                        'Friday' => 'Jumat',
                        'Saturday' => 'Sabtu'
                    ];

                    $months = [
                        'January' => 'Januari',
                        'February' => 'Februari',
                        'March' => 'Maret',
                        'April' => 'April',
                        'May' => 'Mei',
                        'June' => 'Juni',
                        'July' => 'Juli',
                        'August' => 'Agustus',
                        'September' => 'September',
                        'October' => 'Oktober',
                        'November' => 'November',
                        'December' => 'Desember'
                    ];

                    $day_name = $days[date('l', $event_timestamp)];
                    $month_name = $months[date('F', $event_timestamp)];
                    $formatted_date = $day_name . ", " . date('d', $event_timestamp) . " " . $month_name . " " . date('Y', $event_timestamp) . " - " . date('H:i', $event_timestamp);
                    echo $formatted_date;
                    ?>
                </p>
                <p class="fs-6 d-flex align-items-center">
                    <i class="fas fa-map-marker-alt me-2"></i>
                    <a href="<?php 
                    $address = $row['location'];
                    $google_maps_url = "https://www.google.com/maps/search/?api=1&query=" . urlencode($address);
                    echo $google_maps_url; 
                    ?>" target="_blank" class="text-decoration-none" style="color: black;"><?php echo $address; ?></a>
                </p>
                <p class="fs-6 align-items-center">
                    <i class="fas fa-exclamation-triangle text-danger"></i>
                    <?php
                    $registration_deadline = $row['registration_deadline'];
                    $deadline_timestamp = strtotime($registration_deadline);
                    $day_name = $days[date('l', $deadline_timestamp)];
                    $month_name = $months[date('F', $deadline_timestamp)];
                    $formatted_deadline = $day_name . ", " . date('d', $deadline_timestamp) . " " . $month_name . " " . date('Y', $deadline_timestamp);
                    echo "Batas Registrasi: " . $formatted_deadline;
                    ?>
                </p>
                <a href="Pendaftaran Relawan.php?event_name=<?php echo urlencode($event_name); ?>" class="btn btn-danger">Jadi Relawan</a>
                <p class="text-center mt-3">
                <?php 
                    $current_date = date('Y-m-d'); 
                    $days_remaining = (strtotime($registration_deadline) - strtotime($current_date)) / (60 * 60 * 24);
                    if ($days_remaining > 0) {
                        echo "Pendaftaran kurang $days_remaining hari lagi.";
                    } elseif ($days_remaining === 0) {
                        echo "Hari terakhir untuk pendaftaran!";
                    } else {
                        echo "Pendaftaran telah ditutup.";
                    }
                ?>
                </p>
            </div>
        </div>
    </div>
</div>
<?php
}
?>
<footer class="footer">
    <p>&copy; <?= date("Y") ?> Aksi Relawan. All rights reserved.</p>
</footer>
</body>
</html>
