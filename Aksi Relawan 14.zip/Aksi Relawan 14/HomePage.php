<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aksi Relawan</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="Card Event.css">
    <link rel="stylesheet" href="Card Dok.css">
    
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: red;
            color: white;
            padding: 1rem;
            text-align: center;
        }
        .container-1 {
            padding: 2rem;
            text-align: center;
        }
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 1rem;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
      .container-2 {
      display: flex;
      justify-content: space-between; 
      }

      .container-3 {
      display: flex;
      justify-content: space-between; 
      }

      .box {
      flex: 1; 
      background-color: white;
      width: 100%;
      height: 350px;
      padding: 18px;
      margin: 12px;
      font-family: Nunito, sans-serif;
      color:grey;
      text-align: center;
      border: groove;
      cursor:pointer;
      }

      .box-1 {
      background-color: red;
      width:400px;
      padding: 50px;
      margin: 20px;
      font-family: Roboto, sans-serif;
      color: white;
      text-align:center;
      }

      .box-2 {
      flex: 1;
      background-color: white;
      width: 300px;
      height: 100%;
      padding: 14px;
      margin: 10px;
      font-family: Nunito, sans-serif;
      color:grey;
      text-align: center;
      border-radius: 8px;
      border: groove;
      cursor:pointer;
      }

      .btn {
      background-color:white;
      color:red;
      border: none;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 16px;
      margin: 4px 2px;
      cursor: pointer;
      padding: 16px 26px;
      place-items: center;
      }

      .btn-1 {
      background-color:red;
      color:white;
      border: none;
      text-align: center;
      text-decoration: none;
      font-size: 16px;
      margin: 6px 6px;
      cursor: pointer;
      padding: 16px 26px;
      place-items: center;
      }

      .image-box {
        width: 390px; 
        height: 200px; 
        display: inline-flex;
        justify-content: center;
        align-items: center;
        overflow: hidden; 
        margin: 10px;
      }

      .image-box img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }

      .icon-box {
        padding: 10px;
        display: flex;
        align-items: center; 
        text-align: left;
        place-items: center;
        width: 250px;
        margin: 10px;
      }
      
      .icon-box i {
        margin-right: 10px; 
        place-items: center;
      }
      .header .profile-menu a {
        color: rgb(12, 12, 12);
      }
      .header .dropdown-menu {
        right: 0;
        left: auto;
      }
      .profile-icon {
    background-color: transparent;
      }
    </style>
</head>
<body>
<?php
    session_start();
    if (isset($_SESSION['username'])) {
        session_destroy();
    } else {
        echo "";
    }
    ?>
    <header class="bg-danger text-white text-center py-3">
        <h1>Aksi Relawan</h1>
        <p>Bersama Membangun Negeri dengan Aksi Nyata</p>
    </header>

    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
            <img src="images/logo.jpg" alt="Logo Aksi Relawan" style="width: 40px;" class="rounded-circle">
              </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav mx-auto ">
              <li class="nav-item">
                <a class="nav-link" href="#">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Event-Halaman Lain.php">Event</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Donasi.php">Donasi</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Daftar_Dokumentasi.php">Dokumentasi Event</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Contact Us.php">Contact Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="About Us.php">About Us</a>
              </li>
            </ul>
            <div class="dropdown">
              <div class="profile-icon dropdown-toggle" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">?</div>
              <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                  <li><a class="dropdown-item" href="login.php">Login</a></li>
                  <li><a class="dropdown-item" href="buat_akun.php">Sign Up</a></li>
              </ul>
            </div>
          </div>
        </div>
    </nav>

    <div class="container-1" id="dashboard">
        <p>Selamat datang di Aksi Relawan! Mari bergabung dengan kami untuk membantu sesama melalui berbagai kegiatan sosial dan kemanusiaan.</p>
    </div>

    <div class="container-2">
        <div class="box-1">
            <h2> Website No. 1 untuk menjadi Relawan!</h2>
            <p> Jadilah relawan untuk membawa perubahan besar untuk masyarakat lewat kegiatan sosial. Ada beragam kegiatan sosial untuk diikuti.</p>
            <a href="Event-Halaman Lain.php" class="btn btn-danger">Cari Kegiatan</a>
        </div>
        <div class="box">
            <p></p>
            <i class="fa-solid fa-hand-holding-heart fa-3x" style="color:red;"></i>
            <h2> Jadi Relawan</h2>
            <p> Baru pertama kali menjadi relawan? Pelajari selengkapnya untuk mulai mencari pengalaman relawan pertama Anda bersama organisasi kami!</p>
            <a href="Event-Halaman Lain.php" class="btn-1">Jadi Relawan</a>
        </div>
        <div class="box">
            <p></p>
            <i class="fas fa-hands-holding-circle fa-3x" style="color:red"></i>
            <h2> Jadi Donatur</h2>
            <p> Ingin menyalurkan donasi? Pelajari selengkapnya untuk menyalurkan donasi untuk masyarakat yang membutuhkan melalui organisasi kami!</p>
            <a href="Donasi.php" class="btn-1">Jadi Donatur</a>
        </div>
        <div class="box">
            <p></p>
            <i class="fas fa-solid fa-hands-holding-circle fa-3x" style="color:red"></i>
            <h2> Jadi Donatur</h2>
            <p> Pelajari selengkapnya untuk mengetahui kolaborator dan mitra yang telah bekerjasama dengan organisasi kami dalam berbagai kegiatan sosial!</p>
            <a href="#" class="btn-1">Learn More</a>
        </div>
    </div>

    <div class="container mt-5">
        <div class="d-flex justify-content-between mb-3">
          <h4>Event Segera Hadir!</h4>
        </div>
        <div id="eventCarousel" class="carousel slide position-relative" data-bs-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <div class="row">
                <div class="col-md-4">
                  <div class="card">
                    <a href="Event-Relawan Peduli Lansia.php" class="card-link" target="_blank"></a>
                    <img src="Images/event-lansia.jpg" class="card-img-top" alt="Event 1">
                    <div class="card-body">
                      <h5 class="card-title">Relawan Peduli Lansia</h5>
                      <span class="badge bg-success">Sosial</span>
                      <span class="badge bg-danger">Lansia</span>
                        <p class="text-muted mt-2">
                          <i class="fa fa-calendar"></i> Selasa, 31 Desember 2024 2024<br>
                          <i class="fa fa-map-marker-alt"></i> Gayungan, Wonokromo, Surabaya, Jawa Timur
                        </p>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="card">
                    <a href="Event-Go Green - Menanam Pohon.php" class="card-link" target="_blank"></a>
                    <img src="Images/event-gogreen.jpg" class="card-img-top" alt="Event 2">
                    <div class="card-body">
                      <h5 class="card-title">Go Green - Menanam Pohon</h5>
                      <span class="badge bg-success">Lingkungan</span>
                      <span class="badge bg-danger">Umum</span>
                        <p class="text-muted mt-2">
                          <i class="fa fa-calendar"></i> Selasa, 14 Jnuari 2025<br>
                          <i class="fa fa-map-marker-alt"></i> Ketintang, Wonokromo, Surabaya, Jawa Timur
                        </p>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="card">
                    <a href="Event-Berbagi dengan Sahabat Kecil.php" class="card-link" target="_blank"></a>
                    <img src="Images/event-panti.jpg" class="card-img-top" alt="Event 3">
                    <div class="card-body">
                      <h5 class="card-title">Berbagi dengan Sahabat Kecil</h5>
                      <span class="badge bg-success">Sosial</span>
                      <span class="badge bg-danger">Anak</span>
                        <p class="text-muted mt-2">
                          <i class="fa fa-calendar"></i> Senin, 03 Februari 2025<br>
                          <i class="fa fa-map-marker-alt"></i> Karah, Wonokromo, Surabaya, Jawa Timur
                        </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="carousel-item">
              <div class="row">
                <div class="col-md-4">
                  <div class="card">
                    <img src="Images/Mental.jpeg" class="card-img-top" alt="Event 4">
                    <div class="card-body">
                      <h5 class="card-title">Mengajar Mental Health</h5>
                      <span class="badge bg-success">Mental</span>
                      <span class="badge bg-danger">Remaja</span>
                        <p class="text-muted mt-2">
                          <i class="fa fa-calendar"></i> Kamis, 5 Desember 2024<br>
                          <i class="fa fa-map-marker-alt"></i> Gayungan, Wonokromo, Surabaya, Jawa Timur
                        </p>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="card">
                    <img src="Images/susu.jpeg" class="card-img-top" alt="Event 5">
                    <div class="card-body">
                      <h5 class="card-title">Belajar Mtk dan Berbagi Susu</h5>
                      <span class="badge bg-success">Edukasi</span>
                      <span class="badge bg-danger">Anak</span>
                        <p class="text-muted mt-2">
                          <i class="fa fa-calendar"></i> Minggu, 15 Desember 2024<br>
                          <i class="fa fa-map-marker-alt"></i> Ketintang Baru, Wonokromo, Surabaya, Jawa Timur
                        </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#eventCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#eventCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
      </div>

      <div class="container mt-5 position-relative">
        <div class="d-flex justify-content-between mb-3">
          <h4>Dokumentasi Event yang Telah Dilaksanakan!</h4>
        </div>
        <div id="eventCarousel-1" class="carousel slide" data-bs-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <div class="row">
                <div class="col-md-4">
                  <div class="card card-1"> 
                    <a href="Dokumentasi.php" class="card-link"target="_blank"></a>
                    <img src="Images/Event-1.jpeg" class="card-img-top" alt="Event 1">
                    <div class="card-body">
                      <h5 class="card-title">Peduli Kasih</h5>
                      <span class="badge bg-success">Sosial</span>
                      <span class="badge bg-danger">Anak</span>
                        <p class="text-muted mt-2">
                          Berbagi sembako, alat tulis, pakaian, dan susu kepada anak di Panti Asuhan Rif'atus Sholiha, Jalan Ketintang I.
                        </p>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="card card-1"> 
                    <a href="Dokumentasi.php" class="card-link"target="_blank"></a>
                    <img src="Images/event-bersihlingkungan.png" class="card-img-top" alt="Event 2">
                    <div class="card-body">
                      <h5 class="card-title">Clean With Kids</h5>
                      <span class="badge bg-success">Lingkungan</span>
                      <span class="badge bg-danger">Anak</span>
                        <p class="text-muted mt-2">
                          Membersihkan lingkungan di sekitar kawasan pemukiman dekat danau Jalan Pulo Wonokromo bersama anak-anak.
                        </p>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="card card-1"> 
                    <img src="Images/event-sd.jpg" class="card-img-top" alt="Event 3">
                    <div class="card-body">
                      <h5 class="card-title">English Teaching</h5>
                      <span class="badge bg-success">Edukasi</span>
                      <span class="badge bg-danger">Anak</span>
                        <p class="text-muted mt-2">
                          Memberikan ilmu terutama mengenai bahasa inggris kepada anak-anak di SD Dumas.
                        </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="carousel-item">
              <div class="row">
                <div class="col-md-4">
                  <div class="card card-1"> 
                    <img src="Images/event-sembako.jpg" class="card-img-top" alt="Event 4">
                    <div class="card-body">
                      <h5 class="card-title">Menjual Sembako Murah</h5>
                      <span class="badge bg-success">Sosial</span>
                      <span class="badge bg-danger">Umum</span>
                        <p class="text-muted mt-2">
                          Menjual bahan-bahan pokok dengan harga sangat terjangkau di daerah kurang mampu.
                        </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <button class="card-1-carousel-control-next" type="button" data-bs-target="#eventCarousel-1" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
      </div>

      <div class="container mt-5">
        <h2 class="text-center mb-5">Partner Kami</h2>
        <div class="row row-cols-1 row-cols-md-3 g-4">
          <div class="col">
            <div class="card-2">
              <img src="Images/kitalulus.png" class="card-img-top" alt="Partner 1">
            </div>
          </div>
          <div class="col">
            <div class="card-2">
              <img src="Images/myskill.png" class="card-img-top" alt="Partner 2">
            </div>
          </div>
          <div class="col">
            <div class="card-2">
              <img src="Images/paragon.jpg" class="card-img-top" alt="Partner 3">
            </div>
          </div>
          <div class="col">
            <div class="card-2">
              <img src="Images/revoU.jpg" class="card-img-top" alt="Partner 4">
            </div>
          </div>
          <div class="col">
            <div class="card-2">
              <img src="Images/wepose.jpg" class="card-img-top" alt="Partner 5">
            </div>
          </div>
          <div class="col">
            <div class="card-2">
              <img src="Images/snl.jpg" class="card-img-top" alt="Partner 6">
            </div>
          </div>
        </div>
      </div>

    <div class="container-1" id="contact-us">
        <h2>Contact Us</h2>
        <p>Jika Anda memiliki pertanyaan, jangan ragu untuk menghubungi kami:</p>
        <p>Email: aksirelawan@gmail.com</p>
        <p>Telepon: +62 123 456 789</p>
    </div>

    <footer>
        <p>&copy; 2024 Aksi Relawan. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>