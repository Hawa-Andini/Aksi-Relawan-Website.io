-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2024 at 08:04 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aksi_relawan`
--

-- --------------------------------------------------------

--
-- Table structure for table `biodata`
--

CREATE TABLE `biodata` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `telp` varchar(255) NOT NULL,
  `namaEvent` varchar(255) NOT NULL,
  `cv` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

--
-- Dumping data for table `biodata`
--

INSERT INTO `biodata` (`id`, `nama`, `email`, `alamat`, `telp`, `namaEvent`, `cv`, `created_at`, `status`) VALUES
(18, 'Hawa Andini', 'hawa.23238@mhs.unesa.ac.id', 'Jl. Cendrawasih No. 17', '08579173827', 'Go Green - Menanam Pohon', 'CV/1735373732_CV.pdf', '2024-12-28 08:15:32', 1),
(19, 'Arini Rahmatya', 'arini.23158@mhs.unesa.ac.id', 'Jl. Merpati No 20', '08234582768', 'Berbagi dengan Sahabat Kecil', 'CV/1735373784_CV.pdf', '2024-12-28 08:16:24', 2),
(20, ' Farras Fatih', 'muhammad.23149@mhs.unesa.ac.id', 'Jl. Mangga No 45', '08734582768', 'Peduli Lansia', 'CV/1735373849_CV.pdf', '2024-12-28 08:17:29', 1),
(21, 'Hairul Firdani', 'ahmad.23150@mhs.unesa.ac.id', 'Jl. Manggis No 60', '08479173827', 'Berbagi dengan Sahabat Kecil', 'CV/1735373924_CV.pdf', '2024-12-28 08:18:44', 2),
(22, 'Arini Rahmatya', 'arini.23158@mhs.unesa.ac.id', 'Jl. Merpati No 20', '08234582768', 'Go Green - Menanam Pohon', 'CV/1735454863_CV.pdf', '2024-12-29 06:47:43', 2);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `namaLengkap` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telp` varchar(255) NOT NULL,
  `pesan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

-- --------------------------------------------------------

--
-- Table structure for table `donasi`
--

CREATE TABLE `donasi` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telp` varchar(255) NOT NULL,
  `namaEvent` varchar(255) DEFAULT NULL,
  `besar_donasi` decimal(10,0) NOT NULL,
  `metode_pembayaran` enum('BCA','Mandiri','BRI') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `bukti_pembayaran` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

--
-- Dumping data for table `donasi`
--

INSERT INTO `donasi` (`id`, `nama`, `email`, `telp`, `namaEvent`, `besar_donasi`, `metode_pembayaran`, `created_at`, `bukti_pembayaran`) VALUES
(43, 'Arini Rahmatya', 'arini.23158@mhs.unesa.ac.id', '08234582768', 'Go Green - Menanam Pohon', '100000', 'BCA', '2024-12-28 08:41:01', 'uploads/1735454824_Bukti Transfer.jpg'),
(44, 'Hawa Andini', 'hawa.23238@mhs.unesa.ac.id', '08579173827', 'Peduli Lansia', '200000', 'Mandiri', '2024-12-28 08:41:54', 'uploads/1735375319_Bukti Transfer.jpg'),
(45, 'Hairul Firdani', 'ahmad.23150@mhs.unesa.ac.id', '08479173827', 'Berbagi dengan Sahabat Kecil', '500000', 'BRI', '2024-12-28 08:43:18', 'uploads/1735375404_Bukti Transfer.jpg'),
(46, ' Farras Fatih', 'muhammad.23149@mhs.unesa.ac.id', '08734582768', 'Go Green - Menanam Pohon', '300000', 'BCA', '2024-12-28 08:44:26', 'uploads/1735375472_Bukti Transfer.jpg'),
(47, 'Arini Rahmatya', 'arini.23158@mhs.unesa.ac.id', '08234582768', 'Go Green - Menanam Pohon', '200000', 'BCA', '2024-12-29 06:46:53', 'uploads/1735454824_Bukti Transfer.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tambah_dok`
--

CREATE TABLE `tambah_dok` (
  `id` int(11) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `hastag1` varchar(255) NOT NULL,
  `hastag2` varchar(255) NOT NULL,
  `event_date` date NOT NULL,
  `location` varchar(255) NOT NULL,
  `description1` text NOT NULL,
  `description2` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `event_image1` varchar(255) NOT NULL,
  `event_image2` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

--
-- Dumping data for table `tambah_dok`
--

INSERT INTO `tambah_dok` (`id`, `event_name`, `hastag1`, `hastag2`, `event_date`, `location`, `description1`, `description2`, `created_at`, `event_image1`, `event_image2`) VALUES
(7, 'Aksi Peduli Kasih', 'Sosial', 'Anak', '2024-11-26', 'Ketintang, Wonokromo, Surabaya, Jawa Timur', 'Berbagi sembako, alat tulis, dan susu kepada anak di Panti Asuhan Rif\'atus Sholiha', 'Aksi Peduli Kasih adalah sebuah inisiatif sosial untuk berbagi cinta dan perhatian kepada anak-anak di panti asuhan. Dalam acara ini, kita akan bersama-sama menyampaikan donasi berupa kebutuhan sehari-hari, makanan sehat, perlengkapan sekolah, serta hiburan yang mendidik.\r\n\r\nSelain berbagi materi, acara ini juga memberikan kesempatan untuk membangun hubungan yang hangat dengan anak-anak, mendengarkan cerita mereka, dan menginspirasi mereka untuk meraih mimpi. Melalui kegiatan ini, kami berharap dapat memberikan mereka kebahagiaan, harapan, dan kepercayaan diri untuk masa depan.', '2024-12-27 00:56:48', 'Images/676dfb50bedc4-Event-1.jpeg', '676dfb50bf565-event panti 2.jpg,676dfb50bfaa2-event panti 3.jpg'),
(8, 'English Teaching', 'Edukasi ', 'Anak', '2024-08-13', 'Gayungan, Wonokromo, Surabaya, Jawa Timur', 'Memberikan ilmu terutama Bahasa Inggris kepada anak-anak di SD Dumas ', 'Program relawan pengajaran Bahasa Inggris memberikan kesempatan bagi kita untuk berkontribusi langsung dalam meningkatkan keterampilan bahasa di komunitas yang kurang beruntung. Dalam program ini, kita mengajarkan kosakata dasar, melatih kemampuan berbicara, dan membantu peserta mempersiapkan ujian. Selain itu, kita juga memberikan motivasi dan membangun kepercayaan diri peserta agar mereka dapat membuka lebih banyak peluang di masa depan.\r\n\r\nMelalui panduan dan materi belajar yang telah disediakan, kita bekerja sama menciptakan lingkungan belajar yang efektif. Dengan pendekatan ini, kita tidak hanya berbagi ilmu, tetapi juga menjadi inspirasi yang menciptakan dampak positif bagi pendidikan dan masa depan komunitas.', '2024-12-27 01:24:44', 'Images/676e01dcc7bb5-event-sd.jpg', '676e01dcc8b09-anaksd1.jpg,676e01dcc9190-anaksd2.jpg,676e01dcc9531-event-sd.jpg'),
(9, 'Clean With Kids', 'Lingkungan', 'Anak ', '2024-12-11', 'Ketintang, Wonokromo, Surabaya, Jawa Timur', 'Membersihkan lingkungan di sekitar kawasan pemukiman dekat danau Jalan Pulo Wonokromo bersama anak-anak.', 'Clean with Kids adalah kegiatan yang melibatkan anak-anak dan komunitas untuk membersihkan kawasan pemukiman di sekitar danau Jalan Pulo Wonokromo. Selain mengumpulkan sampah dan memilahnya, anak-anak juga diajak memahami pentingnya menjaga kebersihan melalui edukasi lingkungan yang interaktif. Kegiatan ini bertujuan menanamkan kesadaran lingkungan sejak dini sambil menciptakan kawasan yang lebih bersih dan sehat.\r\n\r\nMelalui aksi ini, anak-anak tidak hanya belajar tentang pentingnya kebersihan, tetapi juga ikut serta dalam penghijauan dengan menanam pohon dan berkreasi menggunakan bahan daur ulang. Kegiatan ini diharapkan mampu membangun kepedulian terhadap lingkungan, mempererat solidaritas komunitas, dan memberikan dampak positif yang berkelanjutan bagi generasi mendatang.', '2024-12-28 03:54:53', 'Images/676f768d27a14-event-bersihlingkungan.png', '676f768d286da-cln1.jpg,676f768d28da2-cln3.jpeg'),
(11, 'Menjual Sembako Murah ', 'Sosial', 'Umum ', '2024-12-25', 'Gayungan, Wonokromo, Surabaya, Jawa Timur', 'Menjual bahan-bahan pokok dengan harga sangat terjangkau di daerah kurang mampu. ', 'Menjual Sembako Murah adalah sebuah inisiatif sosial yang bertujuan untuk meringankan beban ekonomi masyarakat kurang mampu. Program ini menyediakan kebutuhan pokok (sembako) dengan kualitas yang terjamin dan harga yang sangat terjangkau, inisiatif ini lahir sebagai respons terhadap kenaikan harga bahan pokok yang sering kali menjadi tantangan berat bagi masyarakat berpenghasilan rendah, khususnya di tengah situasi ekonomi yang tidak stabil. Dengan semangat gotong royong dan kepedulian sosial, program ini diharapkan mampu membantu memenuhi kebutuhan dasar masyarakat yang membutuhkan, sekaligus memperkuat solidaritas dalam komunitas.', '2024-12-29 06:53:49', 'Images/6770f1fdc5e31-6770d1b019eab-event-sembako.jpg', '6770f1fdc61ba-sembako4.jpg,6770f1fdc66df-sembako3.jpeg,6770f1fdc6b8b-sembako2.jpg,6770f1fdc7051-sembako1.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `tambah_event`
--

CREATE TABLE `tambah_event` (
  `id` int(11) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `location` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `event_image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `activity` text NOT NULL,
  `job` text NOT NULL,
  `hastag1` varchar(255) NOT NULL,
  `hastag2` varchar(255) NOT NULL,
  `registration_deadline` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

--
-- Dumping data for table `tambah_event`
--

INSERT INTO `tambah_event` (`id`, `event_name`, `event_date`, `event_time`, `location`, `description`, `event_image`, `created_at`, `activity`, `job`, `hastag1`, `hastag2`, `registration_deadline`) VALUES
(9, 'Go Green - Menanam Pohon', '2024-12-31', '08:10:00', 'Karah, Wonokromo, Surabaya, Jawa Timur', 'Mari bersama-sama berkontribusi dalam acara Go Green - Menanam Pohon!\r\nAyo bergabung dalam aksi nyata untuk menghijaukan bumi kita dengan menanam pohon di kawasan hutan lindung. Dalam acara ini, kita akan bersama-sama menanam 300 pohon untuk menjaga kelestarian lingkungan dan mencegah terjadinya erosi serta kerusakan alam. Jadilah bagian dari gerakan ini dan berikan dampak positif bagi lingkungan kita. Satu tindakan kecil dari kita dapat membantu memulihkan ekosistem alam yang terancam. Daftar sekarang dan ikutlah menanam pohon demi masa depan yang lebih hijau!', '6767701eb84dd2.76426121.jpg', '2024-12-22 01:49:18', 'Arahan akan dilaksanakan secara daring melalui Zoom Meeting dan WhatsApp Group.', 'Nama Pekerjaan: Relawan Penanam Pohon\r\nRelawan Dibutuhkan: 37 orang\r\nTotal Jam Kerja: 5 jam\r\nTugas Relawan: Menanam pohon di kawasan hutan lindung dan menjaga area dari kerusakan.\r\nKriteria Relawan: Pencinta alam dan peduli terhadap lingkungan.\r\nPerlengkapan: Alat penanaman (disediakan), sarung tangan, dan air minum.\r\nDomisili: Surabaya', 'Lingkungan', 'Umum', '2024-12-29'),
(10, 'Berbagi dengan Sahabat Kecil', '2025-01-14', '11:06:00', 'Ketintang, Wonokromo, Surabaya, Jawa Timur', 'Mari Berkontribusi dalam Acara Berbagi dengan Sahabat Kecil!\r\n\r\nBergabunglah dengan kami untuk memberikan dampak positif kepada anak-anak yang membutuhkan dukungan pendidikan dan sosial. Dalam acara ini, kita akan bersama-sama menjadi teman belajar dan bermain bagi anak-anak, memberikan inspirasi, dan membantu mereka mengembangkan potensi terbaik mereka. Jadilah bagian dari gerakan ini dan tunjukkan kepedulian Anda terhadap generasi penerus bangsa. Bersama-sama, kita dapat membangun masa depan yang lebih cerah untuk anak-anak yang membutuhkan.', '67677442d6c996.45429142.jpg', '2024-12-22 02:06:58', 'Arahan akan dilaksanakan secara daring melalui Zoom Meeting dan WhatsApp Group.', 'Nama Pekerjaan: Relawan Sahabat Kecil\r\nRelawan Dibutuhkan: 27 orang\r\nTotal Jam Kerja: 5 jam\r\nTugas Relawan: Menjadi mentor atau teman belajar bagi anak-anak.\r\nKriteria Relawan: Sabar dan peduli terhadap anak-anak.\r\nPerlengkapan: Buku dan alat tulis (disediakan).\r\nDomisili: Surabaya', 'Sosial', 'Acak', '2024-12-12'),
(13, 'Peduli Lansia', '2025-02-03', '09:05:00', 'Gayungan, Wonokromo, Surabaya, Jawa Timur', 'Mari bersama-sama berkontribusi dalam acara Relawan Peduli Lansia!\r\nAyo berbagi cerita, pengalaman, dan memberikan sembako kepada para lansia di panti jompo. Dalam acara ini, kita tidak hanya memberikan bantuan material, tetapi juga memberikan perhatian dan kasih sayang kepada mereka yang membutuhkan. Jadilah bagian dari kegiatan sosial ini dan berikan dampak nyata bagi kehidupan para lansia. Tunjukkan bahwa kepedulian dan waktu yang kita berikan dapat memberikan kebahagiaan bagi mereka. Daftar sekarang dan ikutlah berperan dalam memberikan kebaikan kepada sesama!', '676df642de51b9.63918769.jpg', '2024-12-27 00:35:14', 'Arahan akan dilaksanakan secara daring melalui Zoom Meeting.', 'Nama Pekerjaan: Volunteer\r\nRelawan Dibutuhkan: 20 orang\r\nTotal Jam Kerja: 3 jam\r\nTugas Relawan: Berbagi cerita, pengalaman, dan memberikan sembako kepada para lansia di panti jompo.\r\nKriteria Relawan: Peduli terhadap lansia dan sabar dalam berkomunikasi.\r\nPerlengkapan: Sembako dan pengalaman cerita\r\nDomisili: Surabaya', 'Sosial', 'Lansia', '2025-01-31'),
(21, 'Belajar MTK dan Berbagi Susu', '2025-01-04', '13:50:00', 'Ketintang, Wonokromo, Surabaya, Jawa Timur', 'Mari Berkontribusi dalam Acara Belajar Matematika dan Berbagi Susu!\r\nBergabunglah dengan kami untuk menciptakan pengalaman belajar yang menyenangkan sekaligus memberikan nutrisi sehat kepada anak-anak yang membutuhkan. Dalam acara ini, kita akan bersama-sama mengajarkan konsep dasar matematika secara kreatif dan interaktif, sambil berbagi susu sebagai bentuk kepedulian terhadap kesehatan mereka. Jadilah bagian dari gerakan ini dan bantu anak-anak mengembangkan kemampuan akademik mereka sambil memberikan perhatian terhadap gizi. Bersama, kita bisa menciptakan generasi yang cerdas dan sehat untuk masa depan bangsa.', '6770f18694ef17.23872158.jpeg', '2024-12-29 06:51:50', 'Arahan akan dilaksanakan secara daring melalui Zoom Meeting dan WhatsApp Group.', 'Nama Pekerjaan: Relawan Edukasi dan Gizi\r\nRelawan Dibutuhkan: 30 orang\r\nTotal Jam Kerja: 4 jam\r\nTugas Relawan: Mengajarkan konsep matematika dasar kepada anak-anak dan membagikan susu. \r\nKriteria Relawan:Memiliki kesabaran dan kemampuan menjelaskan dengan baik.\r\nPerlengkapan:Materi pembelajaran matematika dan Susu (akan disiapkan oleh panitia).\r\nDomisili:Surabaya', 'Edukasi', 'Anak ', '2025-01-03');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` enum('admin','relawan') NOT NULL DEFAULT 'relawan',
  `gender` enum('male','female') NOT NULL,
  `foto_profil` varchar(255) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `current_password` varchar(255) NOT NULL,
  `new_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `username`, `password`, `created_at`, `role`, `gender`, `foto_profil`, `birthdate`, `current_password`, `new_password`) VALUES
(1, 'admin1', 'admin1@gmail.com', 'admin1', '12345678', '2024-12-01 23:54:08', 'admin', 'female', 'uploads/pass3.jpeg', '2000-07-27', '', ''),
(2, 'admin2', 'admin2@gmail.com', 'admin2', '12345678', '2024-12-02 06:55:17', 'admin', 'male', NULL, NULL, '', ''),
(3, 'admin3', 'admin3@gmail.com', 'admin3', '12345678', '2024-12-12 06:56:22', 'admin', 'male', NULL, NULL, '', ''),
(5, 'Hairul Firdani', 'ahmad.23150@mhs.unesa.ac.id', 'Dani', '12345678', '2024-12-12 06:38:36', 'relawan', 'male', NULL, NULL, '', ''),
(6, 'Hawa Andini', 'hawa.23238@mhs.unesa.ac.id', 'Hawa', '12345678', '2024-12-26 22:10:53', 'relawan', 'female', 'uploads/pass3.jpeg', '2000-07-27', '', ''),
(7, 'Arini Rahmatya', 'arini.23158@mhs.unesa.ac.id', 'Arini', '12345678', '2024-12-26 22:13:10', 'relawan', 'male', NULL, NULL, '', ''),
(8, ' Farras Fatih', 'muhammad.23149@mhs.unesa.ac.id', 'Faras', '12345678', '2024-12-26 22:17:42', 'relawan', 'male', NULL, NULL, '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `biodata`
--
ALTER TABLE `biodata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donasi`
--
ALTER TABLE `donasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tambah_dok`
--
ALTER TABLE `tambah_dok`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tambah_event`
--
ALTER TABLE `tambah_event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `biodata`
--
ALTER TABLE `biodata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `donasi`
--
ALTER TABLE `donasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `tambah_dok`
--
ALTER TABLE `tambah_dok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tambah_event`
--
ALTER TABLE `tambah_event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
