<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "aksi_relawan";

$koneksi = new mysqli($host, $username, $password, $database);
if (!$koneksi){
    echo "database tidak terkoneksi";
}
?>