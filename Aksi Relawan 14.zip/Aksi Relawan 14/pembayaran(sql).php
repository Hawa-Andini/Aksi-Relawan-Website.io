<?php
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $file = $_FILES["bukti_pembayaran"];
    $target_dir = "uploads/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $fileName = time() . "_" . basename($file["name"]);
    $target_file = $target_dir . $fileName;

    if (move_uploaded_file($file["tmp_name"], $target_file)) {
        $stmt = $koneksi->prepare("UPDATE donasi SET bukti_pembayaran = ? WHERE email = ?");
        $stmt->bind_param("ss", $target_file, $email);

        if ($stmt->execute()) {
            echo "<script>
                    alert('Bukti pembayaran berhasil diunggah.');
                    window.location.href = 'Dashboard(User)_Donasi.php';
                  </script>";
        } else {
            echo "<script>
                    alert('Terjadi kesalahan saat menyimpan data ke database: " . addslashes($stmt->error) . "');
                    window.location.href = 'Dashboard(User)_Donasi.php';
                  </script>";
        }

        $stmt->close();
    } else {
        echo "<script>
                alert('Gagal mengunggah file.');
                window.location.href = 'Dashboard(User)_Donasi.php';
              </script>";
    }

    $koneksi->close();
}
?>
