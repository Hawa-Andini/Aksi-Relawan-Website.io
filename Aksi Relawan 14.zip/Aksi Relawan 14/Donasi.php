<?php
include "koneksi.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit(); 
}

$username = $_SESSION['username'];

$stmt = $koneksi->prepare("SELECT role FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$role = $row['role'] ?? 'relawan'; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style> 
        .footer { 
            background-color: #333; 
            color: white; 
            text-align: center; 
            padding: 1rem; 
            position: fixed; 
            width: 100%; 
            bottom: 0; 
        }
        .profile-icon {
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            cursor: pointer;
        }
    </style>
</head>
<body>
<header class="bg-danger text-white text-center py-3">
    <h1>Aksi Relawan</h1>
    <p>Bersama Membangun Negeri dengan Aksi Nyata</p>
</header>

<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="images/logo.jpg" alt="Logo Aksi Relawan" style="width: 40px;" class="rounded-circle">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav mx-auto ">
                <li class="nav-item"><a class="nav-link" href="HomePage.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="Event-Halaman Lain.php">Event</a></li>
                <li class="nav-item"><a class="nav-link" href="Donasi.php">Donasi</a></li>
                <li class="nav-item"><a class="nav-link" href="Daftar_Dokumentasi.php">Dokumentasi Event</a></li>
                <li class="nav-item"><a class="nav-link" href="Contact Us.php">Contact Us</a></li>
                <li class="nav-item"><a class="nav-link" href="About Us.php">About Us</a></li>
            </ul>
            <div class="dropdown">
                <div class="profile-icon dropdown-toggle" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo htmlspecialchars($username); ?>
                </div>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                    <?php if ($role === 'admin'): ?>
                        <li><a class="dropdown-item" href="Dashboard(Admin).php">Dashboard</a></li>
                    <?php else: ?>
                        <li><a class="dropdown-item" href="Dashboard(User).php">Dashboard</a></li>
                    <?php endif; ?>
                    <li><a class="dropdown-item" href="logout.php">Keluar</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>

<?php
$stmt = $koneksi->prepare("SELECT * FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
?>
<div class="container p-5 my-5 border border-start border-dark">
    <h1 style="text-align: center;">Donasi</h1> <br>
    <p>Dukung kami dengan donasi Anda. Setiap rupiah akan sangat membantu kegiatan sosial yang kami lakukan:</p>
    <form id="donation" action="proses_donasi.php" method="post" enctype="multipart/form-data" novalidate>
        <input type="hidden" name="redirect" value="pembayaran_donasi.php">
        
        <div class="mb-3 mt-3">
            <label for="name" class="form-label">Nama Lengkap</label>
            <input type="text" class="form-control" name="nama" value="<?php echo htmlspecialchars($row['full_name']); ?>" required>
            <div class="invalid-feedback">Please fill out this field.</div>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" required>
            <div class="invalid-feedback">Please provide a valid email.</div>
        </div>

        <div class="mb-3">
            <label for="telp" class="form-label">Nomor Telepon</label>
            <input type="tel" class="form-control" name="telp" placeholder="Masukkan nomor telepon" required>
            <div class="invalid-feedback">Please provide a valid phone number.</div>
        </div>

        <div class="mb-3">
        <label for="namaEvent" class="form-label">Nama Event</label>
        <input type="text" class="form-control" id="namaEvent" name="namaEvent" placeholder="Masukkan Nama Event" required>
        </div>

        <div class="mb-3 mt-3">
            <label for="besarDonasi" class="form-label">Besar Donasi (IDR)</label>
            <input type="text" id="besar_donasi" class="form-control" name="besar_donasi" placeholder="Masukkan Besar Donasi" required>
            <div class="invalid-feedback">Harap masukkan besar donasi.</div>
        </div>

        <div class="mb-3">
            <label for="metodePembayaran" class="form-label">Metode Pembayaran Transfer Bank</label>
            <select class="form-select" id="metode_pembayaran" name="metode_pembayaran" required>
                <option value="" disabled selected>Pilih Bank</option>
                <option value="BCA">BCA</option>
                <option value="Mandiri">Mandiri</option>
                <option value="BRI">BRI</option>
            </select>
            <div class="invalid-feedback">Harap pilih bank tujuan.</div>
        </div>

        <button type="submit" class="btn btn-danger w-100 mb-3" id="daftarBtn"><h5>Kirim</h5></button>
    </form>
</div>
<?php } ?>

<footer class="bg-dark text-white text-center py-3">
    <p>&copy; <?= date("Y") ?> Aksi Relawan. All rights reserved.</p>
</footer>
</body>
</html>
