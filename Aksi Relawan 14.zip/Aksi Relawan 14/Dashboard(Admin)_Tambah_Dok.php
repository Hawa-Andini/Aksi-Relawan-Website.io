<?php
session_start(); 

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
} else {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Dokumentasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="dashboard.css">
    <style>
        .btn-primary {
            background-color: #dc3545; 
            border-color: #dc3545;
        }
        .btn-primary:hover {
            background-color: #c82333; 
            border-color: #c82333;
        }

        .form-group {
            margin-bottom: 1.5rem; 
        }
    </style>
</head>
<body>
<div class="d-flex">
    <div class="sidebar">
        <a href="Dashboard(Admin).php">Dashboard</a>
        <a href="Dashbard(Admin)_Edit_Profil.php">Edit Profil</a>
        <a href="Dashboard(Admin)_Tambah_Event.php">Tambah Event</a>
        <a href="Dashboard(Admin)_Tambah_Dok.php" class="active">Tambah Dokumentasi</a>
    </div>   

    <div class="w-100">
        <div class="header d-flex justify-content-between">
            <div>
                <a href="HomePage.php">Home</a>
                <a href="Event-Halaman Lain.php">Event</a>
                <a href="Daftar_Dokumentasi.php">Dokumentasi Event</a>
                <a href="Contact Us.php">Contact Us</a>
            </div>
            <div class="profile-menu dropdown">
                <a href="#" class="dropdown-toggle text-white" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo htmlspecialchars($username); ?>
                </a>
                <ul class="dropdown-menu" aria-labelledby="profileDropdown">
                    <li><a class="dropdown-item" href="Dashboard(Admin).php">Dashboard</a></li>
                    <li><a class="dropdown-item" href="logout.php">Keluar</a></li>
                </ul>
            </div>
        </div>

        <div class="container mt-5">
            <h2>Tambah Dokumentasi Baru</h2>
            <?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
                <div class="alert alert-success">Dokumentasi berhasil ditambahkan!</div>
            <?php elseif (isset($_GET['status']) && $_GET['status'] == 'error'): ?>
                <div class="alert alert-danger">Gagal menambahkan dokumentasi. Silakan coba lagi.</div>
            <?php endif; ?>

            <form action="tambah_dok(sql).php" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="event_name">Nama Event</label>
                    <input type="text" class="form-control" id="event_name" name="event_name" required>
                </div>
                <div class="form-group">
                    <label for="hastag1">Hastag 1</label>
                    <input type="text" class="form-control" id="hastag1" name="hastag1" required>
                </div>
                <div class="form-group">
                    <label for="hastag2">Hastag 2</label>
                    <input type="text" class="form-control" id="hastag2" name="hastag2" required>
                </div>
                <div class="form-group">
                    <label for="event_date">Tanggal</label>
                    <input type="date" class="form-control" id="event_date" name="event_date" required>
                </div>
                <div class="form-group">
                    <label for="location">Lokasi</label>
                    <input type="text" class="form-control" id="location" name="location" required>
                </div>
                <div class="form-group">
                    <label for="description1">Deskripsi 1</label>
                    <textarea class="form-control" id="description1" name="description1" rows="4" required></textarea>
                </div>
                <div class="form-group">
                    <label for="description2">Deskripsi 2</label>
                    <textarea class="form-control" id="description2" name="description2" rows="4" required></textarea>
                </div>
                <div class="form-group">
                    <label for="event_image1">Gambar Event 1 (maks 2MB)</label><br>
                    <input type="file" id="event_image1" name="event_image1" required>
                </div>

                <div class="form-group">
                    <label for="event_image2">Gambar Event 2 (maks 2MB per file)</label><br>
                    <input type="file" id="event_image2" name="event_image2[]" multiple>
                </div>
                <button type="submit" class="btn btn-primary">Tambah Dokumentasi</button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
