<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $namaLengkap = $_POST['namaLengkap'];
    $email = $_POST['email'];
    $telp = $_POST['telp'];
    $pesan = $_POST['pesan'];


    $koneksi = mysqli_connect("localhost", "root", "", "aksi_relawan");
    if (mysqli_connect_error()) {
        die("Koneksi database gagal: " . mysqli_connect_error());
    }

    $aksi = mysqli_query($koneksi, "INSERT INTO contact (id, namaLengkap, email, telp, pesan) VALUES ('', '$namaLengkap', '$email', '$telp','$pesan')");

    if ($aksi) {
        header("Location: Contact Us.php?status=success");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }

    mysqli_close($koneksi);
    exit();
}
?>
