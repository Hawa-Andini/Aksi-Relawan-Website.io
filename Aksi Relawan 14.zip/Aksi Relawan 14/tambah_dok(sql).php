<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

$conn = new mysqli("localhost", "root", "", "aksi_relawan");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$message = "";
$messageType = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $event_name = $conn->real_escape_string($_POST['event_name']);
    $hastag1 = $conn->real_escape_string($_POST['hastag1'] ?? '');
    $hastag2 = $conn->real_escape_string($_POST['hastag2'] ?? '');
    $event_date = $conn->real_escape_string($_POST['event_date']);
    $location = $conn->real_escape_string($_POST['location']);
    $description1 = $conn->real_escape_string($_POST['description1']);
    $description2 = $conn->real_escape_string($_POST['description2']);

    $uploadDir = "Images/";
    $allowed_types = ['jpg', 'jpeg', 'png'];

    $event_image1 = $_FILES['event_image1']['name'];
    $event_image1_tmp = $_FILES['event_image1']['tmp_name'];
    $event_image1_size = $_FILES['event_image1']['size'];
    $event_image1_ext = pathinfo($event_image1, PATHINFO_EXTENSION);

    if (!in_array(strtolower($event_image1_ext), $allowed_types)) {
        $message = "Tipe file gambar pertama tidak valid.";
        $messageType = "error";
    } elseif ($event_image1_size > 2097152) {
        $message = "Ukuran gambar pertama terlalu besar (maksimal 2MB).";
        $messageType = "error";
    } else {

        $event_image1_path = $uploadDir . uniqid() . "-" . basename($event_image1);
        if (move_uploaded_file($event_image1_tmp, $event_image1_path)) {
            $uploaded_images = [];

            if (isset($_FILES['event_image2'])) {
                foreach ($_FILES['event_image2']['tmp_name'] as $key => $tmp_name) {
                    $file_name = $_FILES['event_image2']['name'][$key];
                    $file_tmp = $_FILES['event_image2']['tmp_name'][$key];
                    $file_size = $_FILES['event_image2']['size'][$key];
                    $file_error = $_FILES['event_image2']['error'][$key];

                    $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
                    if (!in_array(strtolower($file_ext), $allowed_types) || $file_size > 2097152) {
                        continue;
                    }

                    $new_file_name = uniqid() . "-" . basename($file_name);
                    $file_path = $uploadDir . $new_file_name;

                    if (move_uploaded_file($file_tmp, $file_path)) {
                        $uploaded_images[] = $new_file_name;
                    }
                }
            }
            $event_images2_paths = implode(",", $uploaded_images);

            $sql = "INSERT INTO tambah_dok (event_name, hastag1, hastag2, event_date, location, description1, description2, event_image1, event_image2)
                    VALUES ('$event_name', '$hastag1', '$hastag2', '$event_date', '$location', '$description1', '$description2', '$event_image1_path', '$event_images2_paths')";

            if ($conn->query($sql) === TRUE) {
                $message = "Event berhasil ditambahkan!";
                $messageType = "success";
                
            } else {
                $message = "Terjadi kesalahan: " . $conn->error;
                $messageType = "error";
            }
        } else {
            $message = "Gagal mengunggah gambar pertama.";
            $messageType = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Dokumentasi</title>
    <script>
        function showPopup(message, type) {
            alert((type === "success" ? "Berhasil: " : "Gagal: ") + message);
            if (type === "success") {
                window.location.href = "Dashboard(Admin)_Tambah_Dok.php";
            }
        }
    </script>
</head>
<body>
    <?php if (!empty($message)): ?>
        <script>
            showPopup("<?php echo $message; ?>", "<?php echo $messageType; ?>");
        </script>
    <?php endif; ?>
</body>
</html>