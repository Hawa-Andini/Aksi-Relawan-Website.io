<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indorelawan Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
<?php
    session_start();
    include "koneksi.php";

    if (!isset($_SESSION['username'])) {
        die("Sesi username tidak ditemukan.");
    }

    $username = $_SESSION['username'];

    $stmt = $koneksi->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $full_name = $row['full_name'] ?? 'Nama Tidak Ditemukan';

        $foto_profil_path = htmlspecialchars($row['foto_profil']);
        $foto_profil = 'uploads/placeholder.png'; 

        if (!empty($row['foto_profil']) && file_exists($foto_profil_path)) {
            $foto_profil = $foto_profil_path;
        }
    } else {
        $full_name = 'Nama Tidak Ditemukan';
        $foto_profil = 'uploads/placeholder.png';
    }
?>
<div class="d-flex">
    <div class="sidebar">
        <a href="Dashboard(User).php" class="active">Dashboard</a>
        <a href="Dashboard(User)_Aktivitas.php">Aktivitas</a>
        <a href="Dashboard(User)_Edit_Profil.php">Edit Profil</a>
        <a href="Dashboard(User)_Donasi.php">Donasi</a>
    </div>

    <div class="w-100">
        <div class="header d-flex justify-content-between align-items-center p-3">
            <div>
                <a href="HomePage.php">Home</a>
                <a href="Event-Halaman Lain.php">Event</a>
                <a href="Daftar_Dokumentasi.php">Dokumentasi Event</a>
                <a href="Contact Us.php">Contact Us</a>
            </div>
            <div class="profile-menu dropdown">
                <a href="#" class="dropdown-toggle text-white" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo htmlspecialchars($username); ?>
                </a>
                <ul class="dropdown-menu" aria-labelledby="profileDropdown">
                    <li><a class="dropdown-item" href="Dashboard(User).php">Dashboard</a></li>
                    <li><a class="dropdown-item" href="logout.php">Keluar</a></li>
                </ul>
            </div>
        </div>

        <div class="container mt-4">
            <h1>Dashboard</h1>

            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body text-center">
                            <h5 class="card-title">Proses Seleksi Relawan</h5>
                            <p class="card-text">Ayo cari aktivitas, agar menambah pengalaman!</p>
                            <a href="Event-Halaman Lain.php" class="btn btn-danger">Cari Aktivitas</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body text-center">
                            <img src="<?php echo htmlspecialchars($foto_profil); ?>" class="rounded-circle mb-3" alt="Foto Profil" style="width: 120px; height: 150px;">
                            <h5 class="card-title"><?php echo htmlspecialchars($full_name); ?></h5>
                            <hr>
                            <a href="Dashboard(User)_Edit_Profil.php" class="btn btn-primary">Edit Profil</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
