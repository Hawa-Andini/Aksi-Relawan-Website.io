<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Daftar Relawan</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style type="text/css">
    h2 {
        text-align: center;
        margin-top: 20px;
    }
    th, td {
        padding: 10px;
        text-align: center;
        border: 1px solid black;
    }
    .table-danger {
        background-color:  #E63946;
        color: white; 
    }
    .pagination-container {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }
</style>
<body>

<div class="container">
    <h2>LIST DONASI</h2>
    <table class="table-bordered text-center">
        <thead class="table-danger">
            <tr>
                <th>No</th>
                <th>Nama Lengkap</th>
                <th>Email</th>
                <th>Nomor Telepone</th>
                <th>Nama Event</th>
                <th>Jumlah Donasi</th>
                <th>waktu Kirim</th>
                <th>Bukti Transfer</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include "koneksi.php";
            $no = 1;
            $limit = 10; 
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $start = ($page > 1) ? ($page * $limit) - $limit : 0;

            $result = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM donasi");
            $total = mysqli_fetch_assoc($result)['total'];
            $pages = ceil($total / $limit);

            $query = "SELECT * FROM donasi LIMIT $start, $limit";
            $data = mysqli_query($koneksi, $query);

            if (!$data) {
                echo "<tr><td colspan='9'>Database tidak terkoneksi</td></tr>";
            } else {
                while ($row = mysqli_fetch_array($data)) {
                    ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $row['nama']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['telp']; ?></td>
                        <td><?php echo $row['namaEvent']; ?></td>
                        <td>Rp <?php echo number_format($row['besar_donasi'], 0, ',', '.'); ?></td>
                        <td><?php echo $row['created_at']; ?></td>
                        <td>
                            <a href="<?php echo $row['bukti_pembayaran']; ?>" target="_blank">Lihat Bukti Transfer</a>
                        </td>
                    </tr>
                    <?php
                }
            }
            ?>
        </tbody>
    </table>

    <div class="pagination-container">
        <nav>
            <ul class="pagination">
                <li class="page-item <?php if ($page <= 1) echo 'disabled'; ?>">
                    <a class="page-link" href="?page=<?php echo $page - 1; ?>">Previous</a>
                </li>
                <?php for ($i = 1; $i <= $pages; $i++) { ?>
                    <li class="page-item <?php if ($page == $i) echo 'active'; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    </li>
                <?php } ?>
                <li class="page-item <?php if ($page >= $pages) echo 'disabled'; ?>">
                    <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next</a>
                </li>
            </ul>
        </nav>
    </div>

    <div class="text-center mt-4">
        <a href="Dashboard(Admin).php" class="btn btn-danger">Kembali</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
