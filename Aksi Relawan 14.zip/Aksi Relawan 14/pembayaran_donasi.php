<?php
include "koneksi.php";

if (isset($_GET['email']) && isset($_GET['metode'])) {
    $email = $_GET['email'];
    $metode = $_GET['metode'];

    $nomorRekening = [
        "BCA" => "1234567890 (BCA - Yayasan Aksi Relawan)",
        "Mandiri" => "0987654321 (Mandiri - Yayasan Aksi Relawan)",
        "BRI" => "1122334455 (BRI - Yayasan Aksi Relawan)"
    ];

    $rekening = $nomorRekening[$metode] ?? "Metode pembayaran tidak valid.";
} else {
    die("<p style='color: red; text-align: center;'>Email atau metode pembayaran tidak ditemukan.</p>");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran Donasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .small-card {
            max-width: 400px;
            margin: auto;
        }
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 1rem;
        }
        .profile-icon {
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <header class="bg-danger text-white text-center py-3">
        <h1>Aksi Relawan</h1>
        <p>Bersama Membangun Negeri dengan Aksi Nyata</p>
    </header>

    <?php
    session_start();
    $username = $_SESSION['username'] ?? null;
    ?>
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="images/logo.jpg" alt="Logo Aksi Relawan" style="width: 40px;" class="rounded-circle">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mynavbar">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="Event-Halaman Lain.php">Event</a></li>
                    <li class="nav-item"><a class="nav-link" href="Donasi.php">Donasi</a></li>
                    <li class="nav-item"><a class="nav-link" href="Daftar_Dokumentasi.php">Dokumentasi Event</a></li>
                    <li class="nav-item"><a class="nav-link" href="Contact Us.php">Contact Us</a></li>
                    <li class="nav-item"><a class="nav-link" href="About Us.php">About Us</a></li>
                </ul>
                <div class="dropdown">
                    <div class="profile-icon dropdown-toggle" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo htmlspecialchars($username ?? 'Guest'); ?>
                    </div>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                        <?php if ($username): ?>
                            <li><a class="dropdown-item" href="Dashboard(User).php">Dashboard</a></li>
                            <li><a class="dropdown-item" href="logout.php">Keluar</a></li>
                        <?php else: ?>
                            <li><a class="dropdown-item" href="login.php">Login</a></li>
                            <li><a class="dropdown-item" href="buat_akun.php">Sign Up</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <div class="card shadow small-card">
            <div class="card-body">
                <h3 class="card-title text-center mb-4">Pembayaran Donasi</h3>
                <p class="card-text text-center">
                    Silakan transfer ke nomor rekening berikut sesuai metode pembayaran yang Anda pilih:
                </p>
                <p class="card-text text-center">
                    <strong><?= htmlspecialchars($rekening); ?></strong>
                </p>
                <hr>
                <h4 class="text-center">Unggah Bukti Pembayaran</h4>
                <form action="pembayaran(sql).php" method="post" enctype="multipart/form-data" class="mt-4">
                    <input type="hidden" name="email" value="<?= htmlspecialchars($email); ?>">
                    <div class="mb-3">
                        <label for="bukti_pembayaran" class="form-label">Pilih File:</label>
                        <input type="file" class="form-control" name="bukti_pembayaran" id="bukti_pembayaran" accept="image/*" required>
                    </div>
                    <button type="submit" class="btn btn-danger w-100">Kirim Bukti Pembayaran</button>
                </form>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; <?= date("Y") ?> Aksi Relawan. All rights reserved.</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
