<?php
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $telp = $_POST['telp'];
    $namaEvent = $_POST['namaEvent'];
    $besar_donasi = $_POST['besar_donasi'];
    $metode_pembayaran = $_POST['metode_pembayaran'];

    $stmt = $koneksi->prepare("INSERT INTO donasi (nama, email, telp, namaEvent, besar_donasi, metode_pembayaran, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssssss", $nama, $email, $telp, $namaEvent, $besar_donasi, $metode_pembayaran);

    if ($stmt->execute()) {
        header("Location: pembayaran_donasi.php?email=" . urlencode($email) . "&metode=" . urlencode($metode_pembayaran));
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
} else {
    echo "Invalid request method.";
}
?>
