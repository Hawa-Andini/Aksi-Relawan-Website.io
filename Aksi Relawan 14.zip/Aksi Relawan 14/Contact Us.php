<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="Card Event.css">
    <style>
        .footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 1rem;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
        .profile-icon {
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            cursor: pointer;
            background-color: transparent;
        }
    </style>
</head>
<body>
    <header class="bg-danger text-white text-center py-3">
        <h1>Aksi Relawan</h1>
        <p>Bersama Membangun Negeri dengan Aksi Nyata</p>
    </header>

    <?php
    session_start();
    if (isset($_SESSION['username'])) {
        $username = $_SESSION['username'];
    }
    ?>

    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="images/logo.jpg" alt="Logo Aksi Relawan" style="width: 40px;" class="rounded-circle">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mynavbar">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link" href="HomePage.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="Event-Halaman Lain.php">Event</a></li>
                    <li class="nav-item"><a class="nav-link" href="Donasi.php">Donasi</a></li>
                    <li class="nav-item"><a class="nav-link" href="Daftar_Dokumentasi.php">Dokumentasi Event</a></li>
                    <li class="nav-item"><a class="nav-link" href="Contact Us.php">Contact Us</a></li>
                    <li class="nav-item"><a class="nav-link" href="About Us.php">About Us</a></li>
                </ul>
                <div class="dropdown">
                    <div class="profile-icon dropdown-toggle" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo htmlspecialchars($username ?? '?'); ?>
                    </div>
                    <?php
                    if (isset($_SESSION['username'])):
                        include "koneksi.php"; 
                        $stmt = $koneksi->prepare("SELECT role FROM users WHERE username = ?");
                        $stmt->bind_param("s", $_SESSION['username']);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        $row = $result->fetch_assoc();
                        $role = $row['role'] ?? 'relawan'; 
                    ?>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                            <?php if ($role === 'admin'): ?>
                                <li><a class="dropdown-item" href="Dashboard(Admin).php">Dashboard</a></li>
                            <?php else: ?>
                                <li><a class="dropdown-item" href="Dashboard(User).php">Dashboard</a></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="logout.php">Keluar</a></li>
                        </ul>
                    <?php else: ?>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                            <li><a class="dropdown-item" href="login.php">Login</a></li>
                            <li><a class="dropdown-item" href="buat_akun.php">Sign Up</a></li>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <div class="container my-5 border border-2">
        <div class="row">
            <div class="col-md-6 p-5 bg-light">
                <h3>Hubungi Kami</h3>
                <p>Jika Anda memiliki pertanyaan, jangan ragu untuk menghubungi kami:</p>
                <ul class="list-unstyled">
                    <li class="d-flex align-items-center mb-3">
                        <i class="fas fa-envelope fa-lg me-3"></i>
                        <span>Aksirelawan@gmail.com</span>
                    </li>
                    <li class="d-flex align-items-center mb-3">
                        <i class="fas fa-map-marker-alt fa-lg me-3"></i>
                        <span>Jl. Ngagel Jaya Selatan, Ngagelrejo, Kec. Wonokromo, Surabaya, Jawa Timur</span>
                    </li>
                    <li class="d-flex align-items-center mb-3">
                        <i class="fas fa-phone fa-lg me-3"></i>
                        <span>+62 857-6037-4924</span>
                    </li>
                </ul>
            </div>
            <div class="col-md-6 p-5 bg-danger text-white">
                <?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
                    <div class="alert alert-success mt-3">
                        <strong>Success!</strong> Berhasil dikirim
                    </div>
                <?php endif; ?>
                <h3>Tuliskan Pertanyaan!</h3>
                <form id="contactForm" action="submit_contact.php" method="post">
                    <div class="mb-3">
                        <label for="username" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" name="namaLengkap" placeholder="Nama Lengkap" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" placeholder="Email" required>
                    </div>
                    <div class="mb-3">
                        <label for="tel" class="form-label">Nomor Telepon</label>
                        <input type="tel" class="form-control" name="telp" placeholder="Nomor Telepon" required>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Pesan</label>
                        <textarea class="form-control" name="pesan" rows="3" placeholder="Pesan" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-light">Kirim</button>
                </form>
            </div>
        </div>
    </div>

    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; <?= date("Y") ?> Aksi Relawan. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
