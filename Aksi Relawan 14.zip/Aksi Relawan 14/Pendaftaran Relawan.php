<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendaftaran Relawan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
       .profile-icon {
           width: 40px;
           height: 40px;
           color: white;
           border-radius: 50%;
           display: flex;
           align-items: center;
           justify-content: center;
           font-size: 18px;
           cursor: pointer;
       }
</style>
</head>
<body>
<header class="bg-danger text-white text-center py-3">
        <h1>Aksi Relawan</h1>
        <p>Bersama Membangun Negeri dengan Aksi Nyata</p>
    </header>
    <?php
    session_start();
    include "koneksi.php";

    if (isset($_SESSION['username'])) {
        $username = $_SESSION['username'];

        $stmt = $koneksi->prepare("SELECT role, full_name, email FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();

        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $role = $row['role']; 
            $full_name = $row['full_name'];
            $email = $row['email'];
        } else {
            echo "User data not found!";
            exit;
        }
    } else {
        header("Location: login.php");
        exit;
    }
    ?>

    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="images/logo.jpg" alt="Logo Aksi Relawan" style="width: 40px;" class="rounded-circle">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mynavbar">
                <ul class="navbar-nav mx-auto ">
                    <li class="nav-item">
                        <a class="nav-link" href="HomePage.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Event-Halaman Lain.php">Event</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Donasi.php">Donasi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Daftar_Dokumentasi.php">Dokumentasi Event</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Contact Us.php">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="About Us.php">About Us</a>
                    </li>
                </ul>
                <div class="dropdown">
                    <div class="profile-icon dropdown-toggle" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo htmlspecialchars($username); ?>
                    </div>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                        <?php if ($role === 'admin'): ?>
                            <li><a class="dropdown-item" href="Dashboard(Admin).php">Dashboard</a></li>
                        <?php else: ?>
                            <li><a class="dropdown-item" href="Dashboard(User).php">Dashboard</a></li>
                        <?php endif; ?>
                        <li><a class="dropdown-item" href="logout.php">Keluar</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <?php
    if (isset($_GET['event_name'])) {
        $event_name = $_GET['event_name'];
    } else {
        echo "Event name is not set in the URL.";
        exit;
    }
    ?>
    <div class="container p-5 my-5 border border-start border-dark">
        <h1 style="text-align: center;">Pendaftaran Relawan</h1> <br>
        <p>Isi form berikut untuk bergabung menjadi relawan:</p>
        <form id="registrationForm" action="process_registration.php" method="post" enctype="multipart/form-data" novalidate>
            <div class="mb-3 mt-3">
                <label for="name" class="form-label">Nama Lengkap</label>
                <input type="text" class="form-control" name="nama" value="<?php echo htmlspecialchars($full_name); ?>" required>
                <div class="invalid-feedback">Please fill out this field.</div>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                <div class="invalid-feedback">Please provide a valid email.</div>
            </div>
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat</label>
                <input type="text" class="form-control" name="alamat" placeholder="Masukkan alamat" required>
                <div class="invalid-feedback">Please fill out this field.</div>
            </div>
            <div class="mb-3">
                <label for="telp" class="form-label">Nomor Telepon</label>
                <input type="telp" class="form-control" name="telp" placeholder="Masukkan nomor telepon" required>
                <div class="invalid-feedback">Please provide a valid phone number.</div>
            </div>
            <div class="mb-3 mt-3">
                <label for="namaEvent" class="form-label">Nama Event</label>
                <input type="text" class="form-control" name="namaEvent" value="<?php echo htmlspecialchars($event_name); ?>" readonly required>
                <div class="invalid-feedback">Please fill out this field.</div>
            </div>
            <div class="mb-3">
                <label for="cv" class="form-label">Upload CV (PDF)</label>
                <input type="file" class="form-control" id="cv" name="cv" accept=".pdf" required>
                <div class="invalid-feedback">Please upload your CV (PDF).</div>
            </div>
            <button type="submit" class="btn btn-danger w-100 mb-3" id="daftarBtn"><h5>Daftar</h5></button>
        </form>

        <?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
            <div class="alert alert-success alert-dismissible fade show mt-3">
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                <strong>Success!</strong> Pendaftaran berhasil.
            </div>
        <?php elseif (isset($_GET['status']) && $_GET['status'] == 'error'): ?>
            <div class="alert alert-danger alert-dismissible fade show mt-3">
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                <strong>Error!</strong> Terjadi kesalahan, coba lagi.
            </div>
        <?php endif; ?>
    </div>

    <script>
        document.getElementById('registrationForm').addEventListener('submit', function(event) {
            const form = this;

            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }

            form.classList.add('was-validated'); 
        });
    </script>
</body>
</html>
