<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = 'localhost'; 
$dbname = 'aksi_relawan'; 
$username = 'root'; 
$password = ''; 

$koneksi = new mysqli($host, $username, $password, $dbname);
if ($koneksi->connect_error) {
    die("Connection failed: " . $koneksi->connect_error);
}

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'];

$stmt = $koneksi->prepare("
    SELECT 
        A.nama, 
        B.event_name, 
        B.event_date, 
        B.event_time, 
        B.location, 
        A.status 
    FROM biodata A 
    INNER JOIN tambah_event B 
        ON A.namaEvent = B.event_name
    INNER JOIN users C 
        ON A.email = C.email
    WHERE C.username = ?
");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$num_rows = $result->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donasi - Indorelawan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
    <div class="d-flex">
        <div class="sidebar">
            <a href="Dashboard(User).php">Dashboard</a>
            <a href="Dashboard(User)_Aktivitas.php" class="active">Aktivitas</a>
            <a href="Dashboard(User)_Edit_Profil.php">Edit Profil</a>
            <a href="Dashboard(User)_Donasi.php">Donasi</a>
        </div>

        <div class="w-100">
            <div class="header d-flex justify-content-between align-items-center">
                <div>
                    <a href="HomePage.php">Home</a>
                    <a href="Event-Halaman Lain.php">Event</a>
                    <a href="Daftar_Dokumentasi.php">Dokumentasi Event</a>
                    <a href="Contact Us.php">Contact Us</a>
                </div>
                <div class="profile-menu dropdown">
                    <a href="#" class="dropdown-toggle text-white" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo htmlspecialchars($username); ?>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item" href="Dashboard(User).php">Dashboard</a></li>
                        <li><a class="dropdown-item" href="logout.php">Keluar</a></li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="container mt-4">
                <h2>Aktivitas (<?php echo $num_rows; ?>)</h2>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Nama Lengkap</th>
                            <th>Nama Event</th>
                            <th>Tanggal Pelaksanaan</th>
                            <th>Waktu</th>
                            <th>Lokasi</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()) { ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['nama']); ?></td>
                                <td><?php echo htmlspecialchars($row['event_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['event_date']); ?></td>
                                <td><?php echo htmlspecialchars($row['event_time']); ?></td>
                                <td><?php echo htmlspecialchars($row['location']); ?></td>
                                <td>
                                    <?php
                                    if ($row['status'] == 0) {
                                        echo '<span style="color: orange;">Tunggu</span>';
                                    } elseif ($row['status'] == 1) {
                                        echo '<span style="color: green;">Lolos</span>';
                                    } elseif ($row['status'] == 2) {
                                        echo '<span style="color: red;">Tidak Lolos</span>';
                                    } else {
                                        echo 'Unknown';
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
