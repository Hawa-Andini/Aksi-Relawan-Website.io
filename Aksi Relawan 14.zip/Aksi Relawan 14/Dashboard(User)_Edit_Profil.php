<?php
session_start();
$host = 'localhost'; 
$dbname = 'aksi_relawan'; 
$username = 'root'; 
$password = ''; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi gagal: " . $e->getMessage());
}

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'];

$stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
$stmt->bindParam(':username', $username);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $birthdate = $_POST['birthdate'];
    $gender = $_POST['gender'];
    $avatar = $_FILES['avatar']['name'];

    if (!empty($avatar)) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($avatar);
        if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target_file)) {
            $avatar_path = $target_file;
        } else {
            $avatar_path = $user['foto_profil']; 
        }
    } else {
        $avatar_path = $user['foto_profil']; 
    }

    $stmt = $pdo->prepare("UPDATE users SET full_name = :name, email = :email, birthdate = :birthdate, gender = :gender, foto_profil = :avatar WHERE username = :username");
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':birthdate', $birthdate);
    $stmt->bindParam(':gender', $gender);
    $stmt->bindParam(':avatar', $avatar_path);
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $profile_message = "Profil berhasil diperbarui.";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if ($current_password === $user['password']) { 
        if ($new_password === $confirm_password) {
            $stmt = $pdo->prepare("UPDATE users SET password = :password WHERE username = :username");
            $stmt->bindParam(':password', $new_password);
            $stmt->bindParam(':username', $username);
            $stmt->execute();
            $password_message = "Password berhasil diperbarui.";
        } else {
            $password_message = "Password baru dan konfirmasi tidak cocok.";
        }
    } else {
        $password_message = "Password saat ini salah.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profil - Indorelawan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
<div class="d-flex">
    <div class="sidebar">
        <a href="Dashboard(User).php">Dashboard</a>
        <a href="Dashboard(User)_Aktivitas.php">Aktivitas</a>
        <a href="Dashboard(User)_Edit_Profil.php" class="active">Edit Profil</a>
        <a href="Dashboard(User)_Donasi.php">Donasi</a>
    </div>

    <div class="w-100">
        <div class="header d-flex justify-content-between align-items-center">
            <div>
                <a href="HomePage.php">Home</a>
                <a href="Event-Halaman Lain.php">Event</a>
                <a href="Daftar_Dokumentasi.php">Dokumentasi Event</a>
                <a href="Contact Us.php">Contact Us</a>
            </div>
            <div class="profile-menu dropdown">
                <a href="#" class="dropdown-toggle text-white" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false"><?php echo $username ?></a>
                <ul class="dropdown-menu" aria-labelledby="profileDropdown">
                    <li><a class="dropdown-item" href="Dashboard(User).php">Dashboard</a></li>
                    <li><a class="dropdown-item" href="logout.php">Keluar</a></li>
                </ul>
            </div>
        </div>

        <div class="container mt-4">
            <h1>Edit Profil</h1>
            <ul class="nav nav-tabs" id="editProfileTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="true">Profil</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="security-tab" data-bs-toggle="tab" data-bs-target="#security" type="button" role="tab" aria-controls="security" aria-selected="false">Keamanan</button>
                </li>
            </ul>

            <div class="tab-content" id="editProfileTabsContent">
                <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    <div class="card mt-3">
                        <div class="card-body">
                            <?php if (isset($profile_message)) echo "<p class='alert alert-info'>$profile_message</p>"; ?>
                            <form method="POST" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="avatar" class="form-label">Avatar</label>
                                    <input type="file" class="form-control" id="avatar" name="avatar">
                                    <?php if (!empty($user['foto_profil'])): ?>
                                        <img src="<?= $user['foto_profil']; ?>" alt="Avatar" class="img-thumbnail mt-2" width="100">
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <label for="name" class="form-label">Nama</label>
                                    <input type="text" class="form-control" id="name" name="name" value="<?= $user['full_name']; ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?= $user['email']; ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="birthdate" class="form-label">Tanggal Lahir</label>
                                    <input type="date" class="form-control" id="birthdate" name="birthdate" value="<?= $user['birthdate']; ?>">
                                </div>
                                <div class="mb-3">
                                    <label for="gender" class="form-label">Jenis Kelamin</label>
                                    <select class="form-select" id="gender" name="gender">
                                        <option value="male" <?= $user['gender'] === 'male' ? 'selected' : ''; ?>>Laki-Laki</option>
                                        <option value="female" <?= $user['gender'] === 'female' ? 'selected' : ''; ?>>Perempuan</option>
                                    </select>
                                </div>
                                <button type="submit" name="update_profile" class="btn btn-primary">Simpan</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade" id="security" role="tabpanel" aria-labelledby="security-tab">
                    <div class="card mt-3">
                        <div class="card-body">
                            <?php if (isset($password_message)) echo "<p class='alert alert-info'>$password_message</p>"; ?>
                            <form method="POST">
                                <div class="mb-3">
                                    <label for="current-password" class="form-label">Password Saat Ini</label>
                                    <input type="password" class="form-control" id="current-password" name="current_password" required>
                                </div>
                                <div class="mb-3">
                                    <label for="new-password" class="form-label">Password Baru</label>
                                    <input type="password" class="form-control" id="new-password" name="new_password" required>
                                </div>
                                <div class="mb-3">
                                    <label for="confirm-password" class="form-label">Konfirmasi Password Baru</label>
                                    <input type="password" class="form-control" id="confirm-password" name="confirm_password" required>
                                </div>
                                <button type="submit" name="update_password" class="btn btn-primary">Ubah Password</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
