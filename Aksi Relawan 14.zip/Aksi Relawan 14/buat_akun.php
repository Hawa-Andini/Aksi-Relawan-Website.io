<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buat Akun - AksiRelawan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="card p-4 shadow-lg" style="width: 400px;">
            <h2 class="text-center mb-4">Buat Akun</h2>
            <?php
                $conn = new mysqli("localhost", "root", "", "aksi_relawan");
                if ($conn->connect_error) {
                    die("<div class='alert alert-danger'>Koneksi gagal: " . $conn->connect_error . "</div>");
                }

                $message = "";
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $fullName = $conn->real_escape_string($_POST['full_name'] ?? '');
                    $email = $conn->real_escape_string($_POST['email'] ?? '');
                    $username = $conn->real_escape_string($_POST['username'] ?? '');
                    $plainPassword = $conn->real_escape_string($_POST['password']);
                    $confirmPassword = $_POST['confirmPassword'] ?? '';

                    if (empty($fullName) || empty($email) || empty($username) || empty($password) || empty($confirmPassword)) {
                        $message = "Semua field harus diisi!";
                    } elseif ($password !== $confirmPassword) {
                        $message = "Password dan konfirmasi password tidak cocok!";
                    } else {
                        $sql = "SELECT * FROM users WHERE email='$email' OR username='$username'";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            $message = "Email atau username sudah digunakan!";
                        } else {
                            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                            $sql = "INSERT INTO users (full_name, email, username, password, role) VALUES ('$fullName', '$email', '$username', '$plainPassword', 'relawan')";
                            if ($conn->query($sql) === TRUE) {
                                $message = "Akun berhasil dibuat! Silakan login.";
                            } else {
                                $message = "Terjadi kesalahan: " . $conn->error;
                            }
                        }
                    }
                }
            ?>
            <?php if (!empty($message)): ?>
                <div class="alert <?= strpos($message, 'berhasil') !== false ? 'alert-success' : 'alert-danger'; ?>" role="alert">
                    <?= $message; ?>
                </div>
            <?php endif; ?>
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="fullName" class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" placeholder="Masukkan nama lengkap" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan email" required>
                </div>
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" placeholder="Masukkan username" required>
                </div>
                <div class="mb-3 position-relative">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan password" required>
                        <span class="input-group-text" onclick="togglePasswordVisibility('password', this)" style="cursor: pointer;">
                            <i class="bi bi-eye-slash" id="passwordIcon"></i>
                        </span>
                    </div>
                </div>
                <div class="mb-3 position-relative">
                    <label for="confirmPassword" class="form-label">Konfirmasi Password</label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" placeholder="Masukkan ulang password" required>
                        <span class="input-group-text" onclick="togglePasswordVisibility('confirmPassword', this)" style="cursor: pointer;">
                            <i class="bi bi-eye-slash" id="confirmPasswordIcon"></i>
                        </span>
                    </div>
                </div>
                <button type="submit" class="btn btn-danger w-100">Daftar</button>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePasswordVisibility(fieldId, iconElement) {
            const inputField = document.getElementById(fieldId);
            const icon = iconElement.querySelector('i');

            if (inputField.type === "password") {
                inputField.type = "text";
                icon.classList.remove('bi-eye-slash');
                icon.classList.add('bi-eye');
            } else {
                inputField.type = "password";
                icon.classList.remove('bi-eye');
                icon.classList.add('bi-eye-slash');
            }
        }
    </script>
</body>
</html>
