<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indorelawan Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
    <?php
    session_start();
    include "koneksi.php";

    if (!isset($_SESSION['username'])) {
        die("Sesi username tidak ditemukan.");
    }

    $username = $_SESSION['username'];
    
    $stmt = $koneksi->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $full_name = $row['full_name'] ?? 'Nama Tidak Ditemukan';

        $foto_profil_path = htmlspecialchars($row['foto_profil']);
        $foto_profil = 'uploads/placeholder.png'; 

        if (!empty($row['foto_profil'])) {
            if (file_exists($foto_profil_path)) {
                $foto_profil = $foto_profil_path;
            }
        }
    } else {
        $full_name = 'Nama Tidak Ditemukan';
        $foto_profil = 'uploads/placeholder.png';
    }
    ?>
    <div class="d-flex">
        <div class="sidebar">
            <a href="Dashboard(Admin).php" class="active">Dashboard</a>
            <a href="Dashbard(Admin)_Edit_Profil.php">Edit Profil</a>
            <a href="Dashboard(Admin)_Tambah_Event.php">Tambah Event</a>
            <a href="Dashboard(Admin)_Tambah_Dok.php">Tambah Dokumentasi</a>
        </div>
        <?php
        if (isset($_SESSION['username'])) {
            $username = $_SESSION['username'];
        } else {
            echo "User belum login!";
        }
        ?>
        <div class="w-100">
            <div class="header d-flex justify-content-between">
                <div>
                    <a href="HomePage.php">Home</a>
                    <a href="Event-Halaman Lain.php">Event</a>
                    <a href="Daftar_Dokumentasi.php">Dokumentasi Event</a>
                    <a href="Contact Us.php">Contact Us</a>
                </div>
                <div class="profile-menu dropdown">
                    <a href="#" class="dropdown-toggle text-white" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false"><?php echo $username ?></a>
                    <ul class="dropdown-menu" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item" href="Dashboard_(Admin).php">Dashboard</a></li>
                        <li><a class="dropdown-item" href="login.php">Keluar</a></li>
                    </ul>
                </div>
            </div>


            <div class="container">
                <h1 class="mt-4">Dashboard</h1>
                <div class="container mt-4">
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-body text-center">
                                    <h5 class="card-title">Proses Seleksi Relawan</h5>
                                    <p class="card-text">Berikut daftar user yang melamar menjadi relawan.</p>
                                    <a href="List_Relawan.php" class="btn btn-danger">Lihat Daftar Relawan</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-body text-center">
                                    <img src="<?php echo htmlspecialchars($foto_profil); ?>" class="rounded-circle mb-3" alt="Profile" width="120">
                                    <h5 class="card-title"><?php echo htmlspecialchars($full_name); ?></h5>
                                    <hr>
                                    <a href="Dashbard(Admin)_Edit_Profil.php" class="btn btn-primary">Edit Profil</a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-body text-center">
                                    <h5 class="card-title">Daftar Donasi</h5>
                                    <p class="card-text">Berikut daftar user yang memberikan donasi.</p>
                                    <a href="List_Donasi.php" class="btn btn-danger">Lihat Daftar Donasi</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
