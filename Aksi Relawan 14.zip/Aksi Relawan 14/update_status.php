<?php
$koneksi = new mysqli("localhost", "root", "", "aksi_relawan");

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

$action = $_GET['action'];
$id = intval($_GET['id']); 

if ($action == 'accept') {
    $status = 1;
} elseif ($action == 'reject') {
    $status = 2;
} else {
    die("Aksi tidak valid!");
}

$stmt = $koneksi->prepare("UPDATE biodata SET status = ? WHERE id = ?");
$stmt->bind_param("ii", $status, $id);

if ($stmt->execute()) {
    echo "Status berhasil diperbarui!";
    header("Location: List_Relawan.php");
} else {
    echo "Gagal memperbarui status: " . $stmt->error;
}

$stmt->close();
$koneksi->close();
?>
