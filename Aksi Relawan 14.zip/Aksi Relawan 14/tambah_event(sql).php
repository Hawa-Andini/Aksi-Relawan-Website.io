<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

$conn = new mysqli("localhost", "root", "", "aksi_relawan");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
$showPopup = false; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $eventName = $conn->real_escape_string($_POST['event_name'] ?? '');
    $hastag1 = $conn->real_escape_string($_POST['hastag1'] ?? '');
    $hastag2 = $conn->real_escape_string($_POST['hastag2'] ?? '');
    $eventDate = $_POST['event_date'] ?? '';
    $eventTime = $_POST['event_time'] ?? '';
    $location = $conn->real_escape_string($_POST['location'] ?? '');
    $registrationDeadline = $_POST['registration_deadline'] ?? '';
    $description = $conn->real_escape_string($_POST['description'] ?? '');
    $activity = $conn->real_escape_string($_POST['activity'] ?? '');
    $job = $conn->real_escape_string($_POST['job'] ?? '');

    $eventImage = $_FILES['event_image'] ?? null;
    $imageName = $eventImage['name'];
    $imageTmpName = $eventImage['tmp_name'];
    $imageSize = $eventImage['size'];
    $imageError = $eventImage['error'];

    if (empty($eventName) || empty($hastag1) || empty($hastag2) || empty($eventDate) || empty($eventTime) || empty($location) || empty($registrationDeadline) || empty($description) || empty($activity) || empty($job) || empty($imageName)) {
        $message = "Semua field harus diisi!";
        $showPopup = true;
    } else {
        $imageExt = strtolower(pathinfo($imageName, PATHINFO_EXTENSION));
        $allowedExt = ['jpg', 'jpeg', 'png'];
        if (!in_array($imageExt, $allowedExt)) {
            $message = "Hanya gambar dengan ekstensi JPG, JPEG, atau PNG yang diperbolehkan.";
            $showPopup = true;
        } elseif ($imageSize > 2097152) { 
            $message = "Ukuran gambar maksimal 2MB.";
            $showPopup = true;
        } else {
            $newImageName = uniqid('', true) . '.' . $imageExt;
            $imageUploadPath = 'Images/' . $newImageName;

            if (move_uploaded_file($imageTmpName, $imageUploadPath)) {
                $sql = "INSERT INTO tambah_event (event_name, hastag1, hastag2, event_date, event_time, location, registration_deadline, description, activity, job, event_image) 
                        VALUES ('$eventName', '$hastag1', '$hastag2', '$eventDate', '$eventTime', '$location', '$registrationDeadline', '$description', '$activity', '$job', '$newImageName')";
                if ($conn->query($sql) === TRUE) {
                    $message = "Event berhasil ditambahkan!";
                    $showPopup = true;
                } else {
                    $message = "Terjadi kesalahan: " . $conn->error;
                    $showPopup = true;
                    error_log("SQL Error: " . $conn->error);
                }
            } else {
                $message = "Gagal mengunggah gambar.";
                $showPopup = true;
            }
        }
    }
    if ($showPopup) {
        echo "<script>
            alert('$message');
            window.location.href = 'Dashboard(Admin)_Tambah_Event.php';
        </script>";
        exit;
    }
}
?>