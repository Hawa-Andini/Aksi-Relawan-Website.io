<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donasi - Indorelawan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
<div class="d-flex">
    <div class="sidebar">
        <a href="Dashboard(User).php">Dashboard</a>
        <a href="Dashboard(User)_Aktivitas.php">Aktivitas</a>
        <a href="Dashboard(User)_Edit_Profil.php">Edit Profil</a>
        <a href="Dashboard(User)_Donasi.php" class="active">Donasi</a>
    </div>

    <?php
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (isset($_SESSION['username'])) {
        $username = $_SESSION['username'];
    } else {
        header("Location: login.php");
        exit;
    }
    ?>
    <div class="w-100">
        <div class="header d-flex justify-content-between align-items-center">
            <div>
                <a href="HomePage.php">Home</a>
                <a href="Event-Halaman Lain.php">Event</a>
                <a href="Daftar_Dokumentasi.php">Dokumentasi Event</a>
                <a href="Contact Us.php">Contact Us</a>
            </div>
            <div class="profile-menu dropdown">
                <a href="#" class="dropdown-toggle text-white" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo htmlspecialchars($username); ?>
                </a>
                <ul class="dropdown-menu" aria-labelledby="profileDropdown">
                    <li><a class="dropdown-item" href="Dashboard(User).php">Dashboard</a></li>
                    <li><a class="dropdown-item" href="logout.php">Keluar</a></li>
                </ul>
            </div>
        </div>

        <div class="container mt-4">
            <h1 class="mb-4">Donasi</h1>
            <div class="row">
                <!-- Card 1: Informasi Donasi -->
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-body text-center">
                            <h5 class="card-title">Informasi Donasi</h5>
                            <p>Donasi kamu sangat berarti dan memberikan dampak positif yang besar</p>
                            <a href="donasi.php" class="btn btn-danger">Donasi Sekarang</a>
                        </div>
                    </div>
                </div>

                <!-- Card 2: Riwayat Donasi -->
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title text-center">Riwayat Donasi</h5>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Nama Event</th>
                                        <th>Jumlah Donasi</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    include "koneksi.php";

                                    if (session_status() === PHP_SESSION_NONE) {
                                        session_start();
                                    }
                                    
                                    if (!isset($_SESSION['username'])) {
                                        header("Location: login.php");
                                        exit;
                                    }
                                    
                                    $username = $_SESSION['username'];
                                    
                                    $stmt = $koneksi->prepare("
                                        SELECT A.namaEvent, A.besar_donasi
                                        FROM donasi A
                                        INNER JOIN users B ON A.email = B.email
                                        WHERE B.username = ?
                                    ");
                                    if (!$stmt) {
                                        die("Error dalam mempersiapkan query: " . $koneksi->error);
                                    }
                                    
                                    $stmt->bind_param("s", $username);
                                    $stmt->execute();
                                    $result = $stmt->get_result();
                                    
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            echo "<tr>";
                                            echo "<td>" . htmlspecialchars($row['namaEvent']) . "</td>";
                                            echo "<td>Rp. " . number_format($row['besar_donasi'], 0, ',', '.') . "</td>";
                                            echo "<td><span style='color: green;'>Berhasil</span></td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='3'>Belum ada riwayat donasi.</td></tr>";
                                    }
                                    
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
