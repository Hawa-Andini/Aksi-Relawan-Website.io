<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        main {
            flex: 1;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 1rem;
        }

        .profile-icon {
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <header class="bg-danger text-white text-center py-3">
        <h1>Aksi Relawan</h1>
        <p>Bersama Membangun Negeri dengan Aksi Nyata</p>
    </header>

    <?php
    session_start();
    if (isset($_SESSION['username'])) {
        $username = $_SESSION['username'];
    }
    ?>
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="images/logo.jpg" alt="Logo Aksi Relawan" style="width: 40px;" class="rounded-circle">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mynavbar">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link" href="HomePage.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="Event-Halaman Lain.php">Event</a></li>
                    <li class="nav-item"><a class="nav-link" href="Donasi.php">Donasi</a></li>
                    <li class="nav-item"><a class="nav-link" href="Daftar_Dokumentasi.php">Dokumentasi Event</a></li>
                    <li class="nav-item"><a class="nav-link" href="Contact Us.php">Contact Us</a></li>
                    <li class="nav-item"><a class="nav-link" href="About Us.php">About Us</a></li>
                </ul>
                <div class="dropdown">
                    <div class="profile-icon dropdown-toggle" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo htmlspecialchars($username ?? '?'); ?>
                    </div>
                    <?php
                    if (isset($_SESSION['username'])) :
                        include "koneksi.php";
                        $stmt = $koneksi->prepare("SELECT role FROM users WHERE username = ?");
                        $stmt->bind_param("s", $_SESSION['username']);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        $row = $result->fetch_assoc();
                        $role = $row['role'] ?? 'relawan';
                    ?>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                            <?php if ($role === 'admin') : ?>
                                <li><a class="dropdown-item" href="Dashboard(Admin).php">Dashboard</a></li>
                            <?php else : ?>
                                <li><a class="dropdown-item" href="Dashboard(User).php">Dashboard</a></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="logout.php">Keluar</a></li>
                        </ul>
                    <?php else : ?>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                            <li><a class="dropdown-item" href="login.php">Login</a></li>
                            <li><a class="dropdown-item" href="buat_akun.php">Sign Up</a></li>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <main class="container my-5">
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h2 class="card-title text-center">Tentang Kami</h2>
                        <p class="card-text text-center">Aksi Relawan adalah komunitas yang peduli dengan kesejahteraan masyarakat. Kami mengajak semua elemen masyarakat untuk turut serta dalam kegiatan yang kami selenggarakan.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h2 class="card-title text-center">Visi</h2>
                        <p class="card-text text-center">"Menghubungkan orang-orang yang peduli dengan kegiatan sosial, untuk membuat dunia lebih baik melalui aksi relawan."</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h2 class="card-title text-center">Misi</h2>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">Menyediakan informasi tentang berbagai peluang relawan di berbagai bidang.</li>
                            <li class="list-group-item">Menjadi jembatan untuk orang yang ingin berkontribusi dalam hal positif melalui donasi.</li>
                            <li class="list-group-item">Meningkatkan kesadaran masyarakat tentang pentingnya sukarela dan partisipasi aktif dalam kegiatan kemanusiaan.</li>
                            <li class="list-group-item">Mengajak lebih banyak orang untuk terlibat dalam aksi-aksi sosial yang bermanfaat bagi masyarakat.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <p>&copy; <?= date("Y") ?> Aksi Relawan. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>