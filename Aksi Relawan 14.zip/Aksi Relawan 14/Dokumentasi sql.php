<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Dokumentasi Event - Aksi Relawan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        margin: 0;
        font-family: Arial, sans-serif;
        padding-bottom: 60px; 
    }
    .header {
        background-color: #d32f2f;
        color: #fff;
        text-align: center;
        padding: 20px 0;
    }
    .header h1 {
        margin: 0;
        font-size: 2.5rem;
    }
    .header p {
        margin: 0;
        font-size: 1.2rem;
    }
    .navbar-dark {
        background-color: #333;
    }
    .navbar-nav {
        margin: 0 auto;
    }
    .navbar-brand img {
        height: 30px;
    }
    h1 {
        background-color: #d32f2f;
        color: #fff;
        padding: 20px;
        border-radius: 10px 10px 0 0;
    }
    .profile-icon {
        width: 40px;
        height: 40px;
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        cursor: pointer;
    }
    .footer {
        background-color: #333;
        color: white;
        text-align: center;
        padding: 1rem;
        position: fixed;
        width: 100%;
        bottom: 0;
    }
    .container {
        margin-bottom: 60px; 
    }
    </style>
</head>
<body>
<?php
session_start(); 
?>
<div class="header">
    <h1>Aksi Relawan</h1>
    <p>Bersama Membangun Negeri dengan Aksi Nyata</p>
</div>

<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="images/logo.jpg" alt="Avatar Logo" style="width:40px;" class="rounded-pill"> 
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link" href="HomePage.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Event-Halaman Lain.php">Event</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Donasi.php">Donasi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Daftar_Dokumentasi.php">Dokumentasi Event</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Contact Us.php">Contact Us</a>
                </li>
                <li class="nav-item">
                        <a class="nav-link" href="About Us.php">About Us</a>
                </li>
            </ul>
                        <div class="dropdown">
                <div class="profile-icon dropdown-toggle" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo htmlspecialchars($_SESSION['username'] ?? '?'); ?>
                </div>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                    <?php
                    if (isset($_SESSION['username'])) {
                        include "koneksi.php"; 
                        $stmt = $koneksi->prepare("SELECT role FROM users WHERE username = ?");
                        $stmt->bind_param("s", $_SESSION['username']);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        $row = $result->fetch_assoc();
                        $role = $row['role'] ?? 'relawan'; 

                        if ($role === 'admin') {
                            echo '<li><a class="dropdown-item" href="Dashboard(Admin).php">Dashboard</a></li>';
                        } else {
                            echo '<li><a class="dropdown-item" href="Dashboard(User).php">Dashboard</a></li>';
                        }
                        echo '<li><a class="dropdown-item" href="logout.php">Keluar</a></li>';
                    } else {
                        echo '<li><a class="dropdown-item" href="login.php">Login</a></li>';
                        echo '<li><a class="dropdown-item" href="buat_akun.php">Sign Up</a></li>';
                    }
                    ?>
                </ul>
            </div>
        </div>
    </div>
</nav>

            <?php
            include "koneksi.php";
            if (isset($_GET['event_name'])) {
                $event_name = $_GET['event_name'];
            } else {
                echo "<div class='alert alert-danger text-center'>Event name is not set in the URL.</div>";
                exit;
            }

            $stmt = $koneksi->prepare("SELECT * FROM tambah_dok WHERE event_name = ?");
            $stmt->bind_param("s", $event_name);
            $stmt->execute();
            $result = $stmt->get_result();

            while ($row = $result->fetch_assoc()) {
            ?>

            <div class="container mt-4 p-4 bg-white rounded shadow">
                <h1 class="text-center">Dokumentasi Event: <?php echo $row['event_name']?></h1>

                <div class="event-details mb-4">
                    <h2>Detail Event</h2>
                    <p><strong>Tanggal:</strong> <?php echo $row['event_date']?></p>
                    <p><strong>Lokasi:</strong> <?php echo $row['location']?></p>
                    <p><strong>Deskripsi:</strong> <?php echo $row['description2']?></p>
                </div>

                <div class="event-gallery">
                <h2>Dokumentasi Foto</h2>
                <div class="d-flex flex-wrap">
                <?php
                $images = explode(",", $row['event_image2']); 
                foreach ($images as $image) {
                    echo '<img src="Images/' . trim($image) . '" alt="Gambar Event" style="max-width: 300px; margin-right: 10px;">';
                }
                ?>
                </div>
                </div>
            </div>
            <?php
            }
            ?>
            <footer class="footer">
                    <p>&copy; 2024 Aksi Relawan. All Rights Reserved.</p>
                </footer>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>
