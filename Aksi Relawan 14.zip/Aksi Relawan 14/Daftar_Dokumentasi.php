<?php
$conn = new mysqli("localhost", "root", "", "aksi_relawan");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT event_name, event_date, location, description1, description1 FROM tambah_dok ORDER BY event_date ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Dokumentasi Event - Aksi Relawan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: red;
            color: white;
            padding: 1rem;
            text-align: center;
        }
        .card {
            border: none;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            transition: transform 0.3s ease-in-out;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .card img {
            object-fit: cover;
            height: 180px;
            border-radius: 8px 8px 0 0;
        }
        .card-body {
            padding: 1.5rem;
        }
        .card-title {
            font-size: 1.25rem;
            font-weight: bold;
            color: black;
        }
        .card-text {
            font-size: 0.9rem;
            color: #757575;
        }
        .card-footer {
            background-color: #f4f4f4;
            padding: 0.75rem;
            border-top: 1px solid #ddd;
            text-align: center;
        }
        .footer { 
            background-color: #333; 
            color: white; 
            text-align: center; 
            padding: 1rem; 
            position: relative; 
            width: 100%; 
            bottom: 0; 
        }
        .profile-icon {
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<header class="bg-danger text-white text-center py-3">
        <h1>Aksi Relawan</h1>
        <p>Bersama Membangun Negeri dengan Aksi Nyata</p>
    </header>
    <?php
    session_start();
    if (isset($_SESSION['username'])) {
        $username = $_SESSION['username'];
    } 
    ?>
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="images/logo.jpg" alt="Logo Aksi Relawan" style="width: 40px;" class="rounded-circle">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="HomePage.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Event-Halaman Lain.php">Event</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Donasi.php">Donasi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Daftar_Dokumentasi.php">Dokumentasi Event</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Contact Us.php">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="About Us.php">About Us</a>
                    </li>
                </ul>
                <div class="dropdown">
                    <div class="profile-icon dropdown-toggle" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo htmlspecialchars($username ?? '?'); ?>
                    </div>
                    <?php
                    if (isset($_SESSION['username'])):
                        include "koneksi.php";
                        $stmt = $koneksi->prepare("SELECT role FROM users WHERE username = ?");
                        $stmt->bind_param("s", $_SESSION['username']);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        $row = $result->fetch_assoc();
                        $role = $row['role'] ?? 'relawan'; 
                    ?>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                            <?php if ($role === 'admin'): ?>
                                <li><a class="dropdown-item" href="Dashboard(Admin).php">Dashboard</a></li>
                            <?php else: ?>
                                <li><a class="dropdown-item" href="Dashboard(User).php">Dashboard</a></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="logout.php">Keluar</a></li>
                        </ul>
                    <?php else: ?>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                            <li><a class="dropdown-item" href="login.php">Login</a></li>
                            <li><a class="dropdown-item" href="buat_akun.php">Sign Up</a></li>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
    <h2 class="text-center mb-4">Dokumentasi Event</h2>
    <div class="row">
    <?php
        include "koneksi.php";
        $data = mysqli_query($koneksi, "SELECT * FROM tambah_dok");
        while ($row = mysqli_fetch_array($data)) {
        ?>
        <div class="col-md-4 mb-4">
            <a href="Dokumentasi sql.php?event_name=<?php echo urlencode($row['event_name']); ?>" class="text-decoration-none text-dark">
            <div class="card event-card">
                    <img src="<?php echo $row['event_image1']; ?>" class="card-img-top" alt="Gambar Event" 
                        onerror="this.src='Images/placeholder.png';">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $row['event_name']; ?></h5>
                        <div class="mb-2">
                            <span class="badge bg-success"><?php echo $row['hastag1']; ?></span>
                            <span class="badge bg-danger"><?php echo $row['hastag2']; ?></span>
                        </div>
                        <p class="card-text"><?php echo $row['description1']; ?></p>
                    </div>
                </div>
            </a>
        </div>
    <?php
        }
    ?>
    </div>
</div>

            
    <footer class="footer">
        <p>&copy; 2024 Aksi Relawan. All Rights Reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>
