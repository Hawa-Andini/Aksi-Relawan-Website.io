<?php
session_start();
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
} else {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Event</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="dashboard.css">
    <style>
        .btn-primary {
            background-color: #dc3545; 
            border-color: #dc3545;
        }
        .btn-primary:hover {
            background-color: #c82333; 
            border-color: #c82333;
        }
        .form-control, .form-control-file, .btn-primary {
            border-color: #dc3545;
        }
        .form-control:focus, .form-control-file:focus {
            border-color: #dc3545;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25); 
        }
        .container h2 {
            color: #dc3545; 
        }
        .form-group label {
        display: block;
        margin-bottom: 0.5rem; 
        }

        .form-group .form-control-file {
            display: block;
            margin-top: 0.5rem; 
        }

        .form-group {
            margin-bottom: 1.5rem; 
        }
    </style>
</head>
<body>
<div class="d-flex">
        <div class="sidebar">
            <a href="Dashboard(Admin).php">Dashboard</a>
            <a href="Dashbard(Admin)_Edit_Profil.php">Edit Profil</a>
            <a href="Dashboard(Admin)_Tambah_Event.php" class="active">Tambah Event</a>
            <a href="Dashboard(Admin)_Tambah_Dok.php">Tambah Dokumentasi</a>
        </div>

        <div class="w-100">
            <div class="header d-flex justify-content-between">
                <div>
                    <a href="HomePage.php">Home</a>
                    <a href="Event-Halaman Lain.php">Event</a>
                    <a href="Daftar_Dokumentasi.php">Dokumentasi Event</a>
                    <a href="Contact Us.php">Contact Us</a>
                </div>
                <div class="profile-menu dropdown">
                    <a href="#" class="dropdown-toggle text-white" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo htmlspecialchars($username); ?>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item" href="Dashboard(Admin).php">Dashboard</a></li>
                        <li><a class="dropdown-item" href="logout.php">Keluar</a></li>
                    </ul>
                </div>
            </div>

    <div class="container mt-5">
        <h2>Tambah Event Baru</h2>
        <?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
            <div class="alert alert-success">Event berhasil ditambahkan!</div>
        <?php elseif (isset($_GET['status']) && $_GET['status'] == 'error'): ?>
            <div class="alert alert-danger">Gagal menambahkan event. Silakan coba lagi.</div>
        <?php endif; ?>

        <form action="tambah_event(sql).php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="event_name">Nama Event</label>
                <input type="text" class="form-control" id="event_name" name="event_name" required>
            </div>
            <div class="form-group">
                <label for="event_name">Hastag 1</label>
                <input type="text" class="form-control" id="hastag1" name="hastag1" required>
            </div>
            <div class="form-group">
                <label for="event_name">Hastag 2</label>
                <input type="text" class="form-control" id="hastag2" name="hastag2" required>
            </div>
            <div class="form-group">
                <label for="event_date">Tanggal Event</label>
                <input type="date" class="form-control" id="event_date" name="event_date" required>
            </div>
            <div class="form-group">
                <label for="event_time">Waktu Event</label>
                <input type="time" class="form-control" id="event_time" name="event_time" required>
            </div>
            <div class="form-group">
                <label for="location">Lokasi</label>
                <input type="text" class="form-control" id="location" name="location" required>
            </div>
            <div class="form-group">
                <label for="event_date">Batas Registrasi</label>
                <input type="date" class="form-control" id="registration_deadline" name="registration_deadline" required>
            </div>
            <div class="form-group">
                <label for="description">Deskripsi Awal</label>
                <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <label for="description">Detail Aktivitas</label>
                <textarea class="form-control" id="activity" name="activity" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <label for="description">Pekerjaan</label>
                <textarea class="form-control" id="job" name="job" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <label for="event_image">Gambar Event (maks 2MB)</label>
                <input type="file" class="form-control-file" id="event_image" name="event_image" accept="image/*" required>
            </div>
            <button type="submit" class="btn btn-primary">Tambah Event</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
