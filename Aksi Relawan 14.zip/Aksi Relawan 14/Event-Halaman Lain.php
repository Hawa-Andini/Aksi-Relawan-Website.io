<?php
$conn = new mysqli("localhost", "root", "", "aksi_relawan");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT event_name, event_date, event_time, location, description FROM tambah_event ORDER BY event_date ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Berita</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: red;
            color: white;
            padding: 1rem;
            text-align: center;
        }
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 0.5rem;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
        .container {
            margin-bottom: 80px; 
        }
        main {
            padding-bottom: 3rem; 
        }
        .jumbotron {
            background-image: url('images/Volunteer.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
            padding: 100px 0;
        }
        .card {
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            height: 100%; 
            display: flex;
            justify-content: space-between; 
            flex-direction: column; 
            min-height: 350px;
        }
        .card-img-top {
            width: 100%;
            height: 200px; 
            object-fit: cover; 
        }
        .card-body {
            display: flex;
            flex-direction: column;
            justify-content: space-between; 
            height: 100%; /
        }
        .badge {
            font-size: 0.9em;
            margin-right: 5px;
        }
        .card-title {
            font-size: 1.25rem;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .text-muted {
            font-size: 0.9em;
        }
        .container {
            margin-top: 20px;
        }
        .row {
            display: flex;
            justify-content: space-between; 
            gap: 1.5rem; 
        }
        .col-md-4 {
            flex: 1 1 calc(33.333% - 1.5rem); 
            max-width: calc(33.333% - 1.5rem); 
        }
        .event-card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .event-card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
        }
        .event-card.clicked {
            transform: perspective(1000px) rotateY(15deg) scale(1.2);
            box-shadow: 0 12px 20px rgba(0, 0, 0, 0.3);
        }
        .profile-icon {
        width: 40px;
        height: 40px;
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        cursor: pointer;
        }
    </style>
</head>
<body>
<header class="bg-danger text-white text-center py-3">
        <h1>Aksi Relawan</h1>
        <p>Bersama Membangun Negeri dengan Aksi Nyata</p>
    </header>
    <?php
    session_start();
    if (isset($_SESSION['username'])) {
        $username = $_SESSION['username'];
    } 
    ?>
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="images/logo.jpg" alt="Logo Aksi Relawan" style="width: 40px;" class="rounded-circle">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="HomePage.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Event-Halaman Lain.php">Event</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Donasi.php">Donasi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Daftar_Dokumentasi.php">Dokumentasi Event</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Contact Us.php">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="About Us.php">About Us</a>
                    </li>
                </ul>
                <div class="dropdown">
                <div class="profile-icon dropdown-toggle" id="profileDropdown" data-toggle="dropdown" aria-expanded="false">
                    <?php echo htmlspecialchars($username ?? '?'); ?>
                </div>
                <?php
                if (isset($_SESSION['username'])):
                    include "koneksi.php"; 
                    $stmt = $koneksi->prepare("SELECT role FROM users WHERE username = ?");
                    $stmt->bind_param("s", $_SESSION['username']);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    $row = $result->fetch_assoc();
                    $role = $row['role'] ?? 'relawan'; 
                ?>
                    <ul class="dropdown-menu dropdown-menu-end" style="right: 0;" aria-labelledby="profileDropdown">
                        <?php if ($role === 'admin'): ?>
                            <li><a class="dropdown-item" href="Dashboard(Admin).php">Dashboard</a></li>
                        <?php else: ?>
                            <li><a class="dropdown-item" href="Dashboard(User).php">Dashboard</a></li>
                        <?php endif; ?>
                        <li><a class="dropdown-item" href="logout.php">Keluar</a></li>
                    </ul>
                <?php else: ?>
                    <ul class="dropdown-menu dropdown-menu-end" style="right: 0;" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item" href="login.php">Login</a></li>
                        <li><a class="dropdown-item" href="buat_akun.php">Sign Up</a></li>
                    </ul>
                <?php endif; ?>
                </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="jumbotron text-center">
        <h1>Daftar Event</h1>
        <p>Event yang akan dilaksanakan oleh kami!</p>
    </div>

    <div class="container mt-5">
    <div class="row g-3 justify-content-between">
        <?php
        include "koneksi.php";
        $data = mysqli_query($koneksi, "SELECT * FROM tambah_event");
        while ($row = mysqli_fetch_array($data)) {
        ?>
        <div class="col-md-4">
            <a href="Event-Daftar.php?event_name=<?php echo urlencode($row['event_name']); ?>" class="text-decoration-none text-dark">
                <div class="card event-card">
                    <img src="Images/<?php echo $row['event_image']; ?>" class="card-img-top" alt="Gambar Event" 
                        onerror="this.src='Images/placeholder.png';">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $row['event_name']; ?></h5>
                        <div class="mb-2">
                            <span class="badge bg-success"><?php echo $row['hastag1']; ?></span>
                            <span class="badge bg-danger"><?php echo $row['hastag2']; ?></span>
                        </div>
                        <p class="text-muted">
                            <i class="fa fa-calendar"></i> 
                            <?php
                            $event_date = $row['event_date'];
                            $event_timestamp = strtotime($event_date);

                            $days = [
                                'Sunday' => 'Minggu',
                                'Monday' => 'Senin',
                                'Tuesday' => 'Selasa',
                                'Wednesday' => 'Rabu',
                                'Thursday' => 'Kamis',
                                'Friday' => 'Jumat',
                                'Saturday' => 'Sabtu'
                            ];

                            $months = [
                                'January' => 'Januari',
                                'February' => 'Februari',
                                'March' => 'Maret',
                                'April' => 'April',
                                'May' => 'Mei',
                                'June' => 'Juni',
                                'July' => 'Juli',
                                'August' => 'Agustus',
                                'September' => 'September',
                                'October' => 'Oktober',
                                'November' => 'November',
                                'December' => 'Desember'
                            ];

                            $day_name = $days[date('l', $event_timestamp)];
                            $month_name = $months[date('F', $event_timestamp)];
                            $formatted_date = $day_name . ", " . date('d', $event_timestamp) . " " . $month_name . " " . date('Y', $event_timestamp);
                            echo $formatted_date;
                            ?>
                            <br>
                            <i class="fa fa-map-marker-alt"></i> <?php echo $row['location']; ?>
                        </p>

                    </div>
                </div>
            </a>
        </div>
        <?php } ?>
    </div>
</div>

<script>
    const cards = document.querySelectorAll('.event-card');

    cards.forEach(card => {
        card.addEventListener('click', function () {
            cards.forEach(c => c.classList.remove('clicked'));
            this.classList.add('clicked');
        });
    });
    
</script>


<footer class="bg-dark text-white text-center py-3">
    <p>&copy; <?= date("Y") ?> Aksi Relawan. All rights reserved.</p>
</footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
