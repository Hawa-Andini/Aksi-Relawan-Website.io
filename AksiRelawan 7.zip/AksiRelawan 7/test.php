<?php
if (function_exists('mysqli_connect')) {
    echo "Fungsi mysqli_connect() tersedia!";
} else {
    echo "Fungsi mysqli_connect() tidak tersedia.";
}
?>