<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header class="bg-danger text-white text-center py-3">
        <h1>Aksi Relawan</h1>
        <p>Bersama Membangun Negeri dengan Aksi Nyata</p>
    </header>

    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="logo.png" alt="Avatar Logo" style="width:40px;" class="rounded-pill"> 
              </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav mx-auto">
              <li class="nav-item">
                <a class="nav-link" href="Dasboard.html">Dashboard</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="About Us.html">About Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Event.html">Event</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Donasi.html">Donasi</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="Contact Us.html">Contact Us</a>
              </li>
            </ul>
            <form class="d-flex">
              <input class="form-control me-2" type="text" placeholder="Search">
              <button class="btn btn-danger" type="button">Search</button>
            </form>
          </div>
        </div>
      </nav>

      <div class="container my-5 border border-2">
        <div class="row">
            <div class="col-md-6 p-5 bg-light">
                <h3>Hubungi Kami</h3>
                <p>Jika Anda memiliki pertanyaan, jangan ragu untuk menghubungi kami:</p>
                <ul class="list-unstyled">
                    <li class="d-flex align-items-center mb-3">
                        <i class="fas fa-envelope fa-lg me-3"></i>
                        <span>Aksirelawan@gmail.com</span>
                    </li>
                    <li class="d-flex align-items-center mb-3">
                        <i class="fas fa-map-marker-alt fa-lg me-3"></i>
                        <span>Jl. Ngagel Jaya Selatan, Ngagelrejo, Kec. Wonokromo, Surabaya, Jawa Timur</span>
                    </li>
                    <li class="d-flex align-items-center mb-3">
                        <i class="fas fa-phone fa-lg me-3"></i>
                        <span>+62 857-6037-4924</span>
                    </li>
                </ul>
            </div>

            <div class="col-md-6 p-5 bg-danger text-white">
            <?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
                    <div class="alert alert-success mt-3">
                        <strong>Success!</strong> Berhasil dikirim
                    </div>
                <?php endif; ?>
                <h3>Tuliskan Pertanyaan!</h3>
                <form id="contactForm" action="submit_contact.php" method="post" >
                    <div class="mb-3">
                        <label for="username" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" name="nama" placeholder="Nama Lengkap" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" placeholder="Email" required>
                    </div>
                    <div class="mb-3">
                        <label for="tel" class="form-label">Nomor Telepon</label>
                        <input type="tel" class="form-control" name="telp" placeholder="Nomor Telepon" required>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Pesan</label>
                        <textarea class="form-control" name="pesan" rows="3" placeholder="Pesan" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-light">Kirim</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
