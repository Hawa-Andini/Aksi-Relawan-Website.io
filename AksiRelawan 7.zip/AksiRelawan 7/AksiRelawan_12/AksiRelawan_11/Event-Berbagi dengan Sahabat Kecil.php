<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Berbagi dengan Sahabat Kecil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
  <header class="bg-danger text-white text-center py-3">
    <h1>Aksi Relawan</h1>
    <p>Bersama Membangun Negeri dengan Aksi Nyata</p>
  </header>

  <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="logo.png" alt="Avatar Logo" style="width:40px;" class="rounded-pill"> 
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mynavbar">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item">
              <a class="nav-link" href="Dasboard.html">Dashboard</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="About Us.html">About Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="Event.html">Event</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="Donasi.html">Donasi</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="Contact Us.html">Contact Us</a>
            </li>
          </ul>
          <form class="d-flex">
            <input class="form-control me-2" type="text" placeholder="Search">
            <button class="btn btn-danger" type="button">Search</button>
          </form>
        </div>
    </div>
  </nav>

  <div class="container my-5">
    <div class="row">
        <div class="col-lg-8 mb-4">
            <div class="card overflow-auto" style="max-height: 600px;">
                <img src="https://biuus.com/wp-content/uploads/2019/07/komunitas-dinding1-siedo.jpg" class="card-img-top" alt="Event Image">
                <div class="card-body">
                    <h5>Mari bersama-sama berkontribusi dalam acara Berbagi dengan Sahabat Kecil!</h5>
                    <p>Ayo berbagi keceriaan dengan anak-anak dari berbagai latar belakang yang membutuhkan perhatian dan kasih sayang...</p>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card p-3 mb-3">
                <h1>Berbagi dengan Sahabat Kecil</h1>
                <p class="fs-6">
                <i class="fas fa-calendar-alt"></i>
                 <?php 
                    $event_date = "2025-01-12 15:00:00"; 
                    $event_timestamp = strtotime($event_date);

                    $days = [
                    'Sunday' => 'Minggu',
                    'Monday' => 'Senin',
                    'Tuesday' => 'Selasa',
                    'Wednesday' => 'Rabu',
                    'Thursday' => 'Kamis',
                    'Friday' => 'Jumat',
                    'Saturday' => 'Sabtu'
                    ];

                    $months = [
                    'January' => 'Januari',
                    'February' => 'Februari',
                    'March' => 'Maret',
                    'April' => 'April',
                    'May' => 'Mei',
                    'June' => 'Juni',
                    'July' => 'Juli',
                    'August' => 'Agustus',
                    'September' => 'September',
                    'October' => 'Oktober',
                    'November' => 'November',
                    'December' => 'Desember'
                    ];

                    $day_name = $days[date('l', $event_timestamp)];
                    $month_name = $months[date('F', $event_timestamp)];
                    $formatted_date = $day_name . ", " . date('d', $event_timestamp) . " " . $month_name . " " . date('Y, H:i', $event_timestamp);
                    echo $formatted_date." - 17:00";
                 ?>
                </p>
                <p class="fs-6 d-flex align-items-center">
                    <i class="fas fa-map-marker-alt me-2"></i>
                    <a href="<?php 
                    $address = "Ketintang, Wonokromo, Surabaya, Jawa Timur";
                    $google_maps_url = "https://www.google.com/maps/search/?api=1&query=" . urlencode($address);
                    echo $google_maps_url; 
                    ?>" target="_blank" class="text-decoration-none" style="color: black;"><?php echo $address; ?></a>
                </p>
                <p class="fs-6 align-items-center">
                    <i class="fas fa-exclamation-triangle text-danger"></i>
                    <?php
                        $registration_deadline = "2025-01-10";

                        $days = [
                            'Sunday' => 'Minggu',
                            'Monday' => 'Senin',
                            'Tuesday' => 'Selasa',
                            'Wednesday' => 'Rabu',
                            'Thursday' => 'Kamis',
                            'Friday' => 'Jumat',
                            'Saturday' => 'Sabtu'
                            ];

                            $months = [
                            'January' => 'Januari',
                            'February' => 'Februari',
                            'March' => 'Maret',
                            'April' => 'April',
                            'May' => 'Mei',
                            'June' => 'Juni',
                            'July' => 'Juli',
                            'August' => 'Agustus',
                            'September' => 'September',
                            'October' => 'Oktober',
                            'November' => 'November',
                            'December' => 'Desember'
                            ];

                            $deadline_timestamp = strtotime($registration_deadline);
                            $day_name = $days[date('l', $deadline_timestamp)];
                            $month_name = $months[date('F', $deadline_timestamp)];
                            $formatted_deadline = $day_name . ", " . date('d', $deadline_timestamp) . " " . $month_name . " " . date('Y', $deadline_timestamp);
                            echo "Batas Registrasi: " . $formatted_deadline;
                    ?>
                </p>
                <a href="#" class="btn btn-danger">Jadi Relawan</a>
                <p class="text-center mt-3">
                <?php 
                    $current_date = date('Y-m-d'); 
                    $days_remaining = (strtotime($registration_deadline) - strtotime($current_date)) / (60 * 60 * 24);
                    if ($days_remaining > 0) {
                        echo "Pendaftaran kurang $days_remaining hari lagi.";
                    } elseif ($days_remaining === 0) {
                        echo "Hari terakhir untuk pendaftaran!";
                    } else {
                        echo "Pendaftaran telah ditutup.";
                    }
                ?>
                </p>
            </div>
        </div>
  </div>
</body>
</html>
