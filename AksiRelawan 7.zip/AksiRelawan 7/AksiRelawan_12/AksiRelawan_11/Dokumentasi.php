<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Dokumentasi Event - Aksi Relawan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        h1 { background-color: #d32f2f; color: #fff; padding: 20px; border-radius: 10px 10px 0 0; }
        .table th { background-color: #d32f2f; color: #fff; }
    </style>
</head>
<body>

<?php

$eventTitle = "Aksi Peduli Bencana";
$eventDate = "3 Oktober 2024";
$eventLocation = "Desa Daling, Kabupaten Aceh Tengah";
$eventDescription = "Kegiatan ini bertujuan untuk membantu warga yang terdampak banjir bandang di Desa Daling. Relawan kami membantu dalam pendistribusian makanan, obat-obatan, kebutuhan pokok, dan lain lain.";

$donationDetails = [
    ["Kebutuhan" => "Makanan dan Minuman", "Jumlah" => "5.000.000"],
    ["Kebutuhan" => "Obat-obatan", "Jumlah" => "3.000.000"],
    ["Kebutuhan" => "Transportasi", "Jumlah" => "2.000.000"],
    ["Kebutuhan" => "Peralatan Relawan", "Jumlah" => "1.500.000"]
];

$totalDonation = 0;
foreach ($donationDetails as $item) {
    $totalDonation += str_replace(".", "", $item["Jumlah"]); 
}
$totalDonation = number_format($totalDonation, 0, ",", ".");
?>

<div class="container mt-4 p-4 bg-white rounded shadow">
    <h1 class="text-center">Dokumentasi Event: <?= $eventTitle ?></h1>

    <div class="event-details mb-4">
        <h2>Detail Event</h2>
        <p><strong>Tanggal:</strong> <?= $eventDate ?></p>
        <p><strong>Lokasi:</strong> <?= $eventLocation ?></p>
        <p><strong>Deskripsi:</strong> <?= $eventDescription ?></p>
    </div>

    <div class="event-donation mb-4">
        <h2>Laporan Penggunaan Dana</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Kebutuhan</th>
                    <th>Jumlah (Rp)</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($donationDetails as $item): ?>
                    <tr>
                        <td><?= $item["Kebutuhan"] ?></td>
                        <td><?= $item["Jumlah"] ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <td><strong>Total</strong></td>
                    <td><strong><?= $totalDonation ?></strong></td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="event-gallery">
        <h2>Dokumentasi Foto</h2>
        <div class="d-flex flex-wrap">
            <img src="c:\Users\ASUS\Downloads\Bencana 1.jpeg" alt="Foto 1" class="img-fluid m-2" style="max-width: 300px;">
            <img src="c:\Users\ASUS\Downloads\Bencana 3.jpg" alt="Foto 2" class="img-fluid m-2" style="max-width: 300px;">
            <img src="c:\Users\ASUS\Downloads\8f304_gotong-royong.jpg" alt="Foto 3" class="img-fluid m-2" style="max-width: 300px;">
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>
