<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buat Akun - AksiRelawan</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="card p-4 shadow-lg" style="width: 400px;">
            <h2 class="text-center mb-4">Buat Akun Untuk Anda</h2>
            <?php
                $message = "";
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $fullName = $_POST['fullName'] ?? '';
                    $email = $_POST['email'] ?? '';
                    $username = $_POST['username'] ?? '';
                    $password = $_POST['password'] ?? '';
                    $confirmPassword = $_POST['confirmPassword'] ?? '';

                    if (empty($fullName) || empty($email) || empty($username) || empty($password) || empty($confirmPassword)) {
                        $message = "Semua field harus diisi!";
                    } elseif ($password !== $confirmPassword) {
                        $message = "Password dan Konfirmasi Password tidak cocok!";
                    } else {
                        $message = "Akun Anda sudah berhasil dibuat, silahkan login kembali!";
                    }
                }
            ?>
            <?php if (!empty($message)): ?>
                <div class="alert <?= ($message === "Akun Anda sudah berhasil dibuat, silahkan login kembali!") ? 'alert-success' : 'alert-danger'; ?>" role="alert">
                    <?= $message; ?>
                </div>
            <?php endif; ?>
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="fullName" class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" id="fullName" name="fullName" value="<?= htmlspecialchars($fullName ?? '') ?>" placeholder="Masukkan nama lengkap" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($email ?? '') ?>" placeholder="Masukkan email" required>
                </div>
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" value="<?= htmlspecialchars($username ?? '') ?>" placeholder="Masukkan username" required>
                </div>
                <div class="mb-3 position-relative">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan password" required>
                        <span class="input-group-text" onclick="togglePasswordVisibility('password', this)" style="cursor: pointer;">
                            <i class="bi bi-eye-slash" id="passwordIcon"></i>
                        </span>
                    </div>
                </div>
                <div class="mb-3 position-relative">
                    <label for="confirmPassword" class="form-label">Konfirmasi Password</label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" placeholder="Masukkan ulang password" required>
                        <span class="input-group-text" onclick="togglePasswordVisibility('confirmPassword', this)" style="cursor: pointer;">
                            <i class="bi bi-eye-slash" id="confirmPasswordIcon"></i>
                        </span>
                    </div>
                </div>
                <button type="submit" class="btn btn-danger w-100 mb-3">Daftar</button>
                <div class="text-center">
                    <p>Sudah punya akun? <a href="login.html" class="text-danger">Masuk di sini</a></p>
                </div>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Fungsi untuk toggle visibility password
        function togglePasswordVisibility(fieldId, iconElement) {
            const inputField = document.getElementById(fieldId);
            const icon = iconElement.querySelector('i');

            if (inputField.type === "password") {
                inputField.type = "text";
                icon.classList.remove('bi-eye-slash');
                icon.classList.add('bi-eye');
            } else {
                inputField.type = "password";
                icon.classList.remove('bi-eye');
                icon.classList.add('bi-eye-slash');
            }
        }
    </script>
</body>
</html>
