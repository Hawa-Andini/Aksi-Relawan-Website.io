<?php
// Memulai sesi untuk menampilkan pesan keberhasilan atau error
session_start();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Event</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: #dc3545; /* Warna merah untuk navbar */
        }
        .navbar-brand, .nav-link {
            color: white !important; /* Warna teks putih untuk navbar */
        }
        .navbar-nav .nav-link:hover {
            color: #f8f9fa !important; /* Warna putih saat hover */
        }
        .btn-primary {
            background-color: #dc3545; /* Warna tombol merah */
            border-color: #dc3545;
        }
        .btn-primary:hover {
            background-color: #c82333; /* Warna tombol merah lebih gelap saat hover */
            border-color: #c82333;
        }
        .form-control, .form-control-file, .btn-primary {
            border-color: #dc3545;
        }
        .form-control:focus, .form-control-file:focus {
            border-color: #dc3545;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25); /* Fokus border merah */
        }
        .container h2 {
            color: #dc3545; /* Judul dengan warna merah */
        }
    </style>
</head>
<body>
    <!-- Responsive Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="#">AksiRelawan</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
                <li class="nav-item"><a class="nav-link" href="event.php">Event</a></li>
                <li class="nav-item"><a class="nav-link" href="documentation.php">Event Documentation</a></li>
                <li class="nav-item"><a class="nav-link" href="donasi.php">Donasi</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <h2>Tambah Event Baru</h2>

        <!-- Menampilkan pesan sukses atau error -->
        <?php
        if (isset($_SESSION['message'])) {
            echo '<div class="alert alert-' . $_SESSION['message_type'] . '">' . $_SESSION['message'] . '</div>';
            unset($_SESSION['message']);
        }
        ?>

        <form action="proses_tambah_event.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="event_name">Nama Event</label>
                <input type="text" class="form-control" id="event_name" name="event_name" required>
            </div>
            <div class="form-group">
                <label for="event_date">Tanggal Event</label>
                <input type="date" class="form-control" id="event_date" name="event_date" required>
            </div>
            <div class="form-group">
                <label for="event_time">Waktu Event</label>
                <input type="time" class="form-control" id="event_time" name="event_time" required>
            </div>
            <div class="form-group">
                <label for="location">Lokasi</label>
                <input type="text" class="form-control" id="location" name="location" required>
            </div>
            <div class="form-group">
                <label for="description">Deskripsi</label>
                <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <label for="event_image">Gambar Event (maks 2MB)</label>
                <input type="file" class="form-control-file" id="event_image" name="event_image" required>
            </div>
            <button type="submit" class="btn btn-primary">Tambah Event</button>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
