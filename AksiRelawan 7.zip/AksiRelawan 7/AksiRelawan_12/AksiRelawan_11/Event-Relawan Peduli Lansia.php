<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relawan Peduli Lansia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  </head>
<body>

  <header class="bg-danger text-white text-center py-3">
    <h1>Aksi Relawan</h1>
    <p>Bersama Membangun Negeri dengan Aksi Nyata</p>
  </header>

  <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="logo.png" alt="Avatar Logo" style="width:40px;" class="rounded-pill"> 
          </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mynavbar">
        <ul class="navbar-nav mx-auto">
          <li class="nav-item">
            <a class="nav-link" href="Dasboard.html">Dashboard</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="About Us.html">About Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Event.html">Event</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Donasi.html">Donasi</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="Contact Us.html">Contact Us</a>
          </li>
        </ul>
        <form class="d-flex">
          <input class="form-control me-2" type="text" placeholder="Search">
          <button class="btn btn-danger" type="button">Search</button>
        </form>
      </div>
    </div>
  </nav>

  <div class="container my-5">
    <div class="row">
        <div class="col-lg-8 mb-4">
            <div class="card overflow-auto" style="max-height: 600px;">
                <img src="https://assets.pikiran-rakyat.com/crop/0x0:0x0/703x0/webp/photo/2023/08/01/2251662413.jpg" class="card-img-top" alt="Event Image">
                <div class="card-body">
                    <div class="row">
                            <div class="mt-3">
                              <h5>Mari bersama-sama berkontribusi dalam acara Relawan Peduli Lansia!</h5>
                              <p style="text-align: justify;">
                                Ayo berbagi cerita, pengalaman, dan memberikan sembako kepada para lansia di panti jompo. Dalam acara ini, 
                                kita tidak hanya memberikan bantuan material, tetapi juga memberikan perhatian dan kasih sayang kepada mereka 
                                yang membutuhkan. Jadilah bagian dari kegiatan sosial ini dan berikan dampak nyata bagi kehidupan para lansia. 
                                Tunjukkan bahwa kepedulian dan waktu yang kita berikan dapat memberikan kebahagiaan bagi mereka. Daftar sekarang dan 
                                ikutlah berperan dalam memberikan kebaikan kepada sesama!</p>
                                <h5>Detail Aktivitas</h5>
                                <p>
                                    Arahan akan dilaksanakan secara daring melalui Zoom Meeting.</p>
                                <h5>Pekerjaan</h5>
                                <h5>Pekerjaan</h5>
                                <ul>
                                    <li>Nama Pekerjaan: Volunteer</li>
                                    <li>Relawan Dibutuhkan: 20 orang</li>
                                    <li>Total Jam Kerja: 3 jam</li>
                                    <li>Tugas Relawan:  Berbagi cerita, pengalaman, dan memberikan sembako kepada para lansia di panti jompo.</li>
                                    <li>Kriteria Relawan: Peduli terhadap lansia dan sabar dalam berkomunikasi.</li>
                                    <li>Perlengkapan: Sembako dan pengalaman cerita</li>
                                    <li>Domisili: Surabaya</li>
                                </ul>
                            </div>
                        </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card p-3 mb-3">
                <h1>Berbagi dengan Sahabat Kecil</h1>
                <p class="fs-6">
                <i class="fas fa-calendar-alt"></i>
                 <?php 
                    $event_date = "2024-10-29 09:00:00"; 
                    $event_timestamp = strtotime($event_date);

                    $days = [
                    'Sunday' => 'Minggu',
                    'Monday' => 'Senin',
                    'Tuesday' => 'Selasa',
                    'Wednesday' => 'Rabu',
                    'Thursday' => 'Kamis',
                    'Friday' => 'Jumat',
                    'Saturday' => 'Sabtu'
                    
                ];

                $months = [
                    'January' => 'Januari',
                    'February' => 'Februari',
                    'March' => 'Maret',
                    'April' => 'April',
                    'May' => 'Mei',
                    'June' => 'Juni',
                    'July' => 'Juli',
                    'August' => 'Agustus',
                    'September' => 'September',
                    'October' => 'Oktober',
                    'November' => 'November',
                    'December' => 'Desember'
                ];

                    $day_name = $days[date('l', $event_timestamp)];
                    $month_name = $months[date('F', $event_timestamp)];
                    $formatted_date = $day_name . ", " . date('d', $event_timestamp) . " " . $month_name . " " . date('Y, H:i', $event_timestamp);
                    echo $formatted_date." - 12:00";
                 ?>
                </p>
                <p class="fs-6 d-flex align-items-center">
                    <i class="fas fa-map-marker-alt me-2"></i>
                    <a href="<?php 
                    $address = "Gayungan, Wonokromo, Surabaya, Jawa Timur";
                    $google_maps_url = "https://www.google.com/maps/search/?api=1&query=" . urlencode($address);
                    echo $google_maps_url; 
                    ?>" target="_blank" class="text-decoration-none" style="color: black;"><?php echo $address; ?></a>
                </p>
                <p class="fs-6 align-items-center">
                    <i class="fas fa-exclamation-triangle text-danger"></i>
                        <?php
                            $registration_deadline = "2024-10-27";

                            $days = [
                            'Sunday' => 'Minggu',
                            'Monday' => 'Senin',
                            'Tuesday' => 'Selasa',
                            'Wednesday' => 'Rabu',
                            'Thursday' => 'Kamis',
                            'Friday' => 'Jumat',
                            'Saturday' => 'Sabtu'
                            ];

                            $months = [
                            'January' => 'Januari',
                            'February' => 'Februari',
                            'March' => 'Maret',
                            'April' => 'April',
                            'May' => 'Mei',
                            'June' => 'Juni',
                            'July' => 'Juli',
                            'August' => 'Agustus',
                            'September' => 'September',
                            'October' => 'Oktober',
                            'November' => 'November',
                            'December' => 'Desember'
                            ];

                            $deadline_timestamp = strtotime($registration_deadline);
                            $day_name = $days[date('l', $deadline_timestamp)];
                            $month_name = $months[date('F', $deadline_timestamp)];
                            $formatted_deadline = $day_name . ", " . date('d', $deadline_timestamp) . " " . $month_name . " " . date('Y', $deadline_timestamp);
                            echo "Batas Registrasi: " . $formatted_deadline;
                        ?>
                </p>
                <a href="#" class="btn btn-danger">Jadi Relawan</a>
                <p class="text-center mt-3">
                <?php 
                    $current_date = date('Y-m-d'); 
                    $days_remaining = (strtotime($registration_deadline) - strtotime($current_date)) / (60 * 60 * 24);
                    if ($days_remaining > 0) {
                        echo "Pendaftaran kurang $days_remaining hari lagi.";
                    } elseif ($days_remaining === 0) {
                        echo "Hari terakhir untuk pendaftaran!";
                    } else {
                        echo "Pendaftaran telah ditutup.";
                    }
                ?>
                </p>
            </div>
        </div>
  </div>
</body>
</html>
