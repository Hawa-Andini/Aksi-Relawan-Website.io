<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendaftaran Relawan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container p-5 my-5 border border-start border-dark">
        <h1>Pendaftaran Relawan</h1>
        <p>Isi form berikut untuk bergabung menjadi relawan:</p>
        <form id="registrationForm" action="process_registration.php" method="post" enctype="multipart/form-data" novalidate>
            <div class="mb-3 mt-3">
                <label for="name" class="form-label">Nama Lengkap</label>
                <input type="text" class="form-control" name="nama" placeholder="Masukkan nama lengkap" required>
                <div class="invalid-feedback">Please fill out this field.</div>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" name="email" placeholder="Masukkan email" required>
                <div class="invalid-feedback">Please provide a valid email.</div>
            </div>
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat</label>
                <input type="text" class="form-control" name="alamat" placeholder="Masukkan alamat" required>
                <div class="invalid-feedback">Please fill out this field.</div>
            </div>
            <div class="mb-3">
                <label for="telp" class="form-label">Nomor Telepon</label>
                <input type="telp" class="form-control" name="telp" placeholder="Masukkan nomor telepon" required>
                <div class="invalid-feedback">Please provide a valid phone number.</div>
            </div>
            <div class="mb-3">
                <label for="pwd" class="form-label">Password</label>
                <input type="password" class="form-control" name="pwd" placeholder="Masukkan password" required>
                <div class="invalid-feedback">Please fill out this field.</div>
            </div>
            <div class="mb-3">
                <label for="pwdConfirm" class="form-label">Ulangi Password</label>
                <input type="password" class="form-control" name="pwdConfirm" placeholder="Ulangi password" required>
                <div class="invalid-feedback">Please fill out this field.</div>
            </div>
            <div class="mb-3 mt-3">
                <label for="namaEvent" class="form-label">Nama Event</label>
                <input type="text" class="form-control" name="namaEvent" placeholder="Masukkan nama event yang ingin kamu daftar" required>
                <div class="invalid-feedback">Please fill out this field.</div>
            </div>
            <div class="mb-3">
                <label for="cv" class="form-label">Upload CV (PDF)</label>
                <input type="file" class="form-control" id="cv" name="cv" accept=".pdf" required>
                <div class="invalid-feedback">Please upload your CV (PDF).</div>
            </div>
            <div class="form-check mb-3">
                <label class="form-check-label">
                    <input class="form-check-input" type="checkbox" name="remember" required> Remember me
                </label>
                <div class="invalid-feedback">You must agree to this checkbox.</div>
            </div>
            <button type="submit" class="btn btn-danger w-100 mb-3" id="daftarBtn"><h5>Daftar</h5></button>
        </form>

        <?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
            <div class="alert alert-success alert-dismissible fade show mt-3">
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                <strong>Success!</strong> Pendaftaran berhasil.
            </div>
        <?php elseif (isset($_GET['status']) && $_GET['status'] == 'error'): ?>
            <div class="alert alert-danger alert-dismissible fade show mt-3">
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                <strong>Error!</strong> Terjadi kesalahan, coba lagi.
            </div>
        <?php endif; ?>
    </div>

    <script>
        document.getElementById('registrationForm').addEventListener('submit', function(event) {
            const form = this;

            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }

            form.classList.add('was-validated'); 
        });

        document.getElementById('registrationForm').addEventListener('submit', function(event) {
            const pwd = document.querySelector('input[name="pwd"]').value;
            const pwdConfirm = document.querySelector('input[name="pwdConfirm"]').value;

            if (pwd !== pwdConfirm) {
                alert('Password dan konfirmasi password tidak cocok.');
                event.preventDefault();
            }
        });
    </script>
</body>
</html>
