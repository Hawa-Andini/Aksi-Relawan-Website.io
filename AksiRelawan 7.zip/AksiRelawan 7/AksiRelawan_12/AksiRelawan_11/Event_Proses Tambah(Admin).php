<?php
session_start();

// Mengambil data dari form
$event_name = $_POST['event_name'];
$event_date = $_POST['event_date'];
$event_time = $_POST['event_time'];
$location = $_POST['location'];
$description = $_POST['description'];

// Menangani upload file gambar
$target_dir = "uploads/"; // Direktori untuk menyimpan gambar
$target_file = $target_dir . basename($_FILES["event_image"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

// Cek apakah file gambar sebenarnya adalah gambar
if (isset($_POST["submit"])) {
    $check = getimagesize($_FILES["event_image"]["tmp_name"]);
    if ($check !== false) {
        $uploadOk = 1;
    } else {
        $_SESSION['message'] = "File yang diupload bukan gambar.";
        $_SESSION['message_type'] = "danger";
        $uploadOk = 0;
    }
}

// Cek ukuran file
if ($_FILES["event_image"]["size"] > 2097152) { // 2MB
    $_SESSION['message'] = "Maaf, gambar terlalu besar.";
    $_SESSION['message_type'] = "danger";
    $uploadOk = 0;
}

// Izinkan format file tertentu
if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
    $_SESSION['message'] = "Maaf, hanya file gambar dengan format JPG, JPEG, PNG, dan GIF yang diizinkan.";
    $_SESSION['message_type'] = "danger";
    $uploadOk = 0;
}

// Jika $uploadOk == 0 berarti ada kesalahan saat upload
if ($uploadOk == 0) {
    $_SESSION['message'] = "Gambar tidak bisa diupload.";
    $_SESSION['message_type'] = "danger";
} else {
    if (move_uploaded_file($_FILES["event_image"]["tmp_name"], $target_file)) {
        // Simpan data event ke database (misalnya, menggunakan MySQL)
        // Kode untuk menyimpan data ke database

        // Pesan sukses
        $_SESSION['message'] = "Event berhasil ditambahkan!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Terjadi kesalahan saat mengunggah gambar.";
        $_SESSION['message_type'] = "danger";
    }
}

// Arahkan kembali ke halaman tambah_event.php
header("Location: tambah_event.php");
exit();
