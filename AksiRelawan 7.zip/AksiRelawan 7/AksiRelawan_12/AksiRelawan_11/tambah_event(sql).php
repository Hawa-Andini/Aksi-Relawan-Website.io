<?php
// Aktifkan error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "aksi_relawan");

// Periksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil data form
    $eventName = $conn->real_escape_string($_POST['event_name'] ?? '');
    $eventDate = $_POST['event_date'] ?? '';
    $eventTime = $_POST['event_time'] ?? '';
    $location = $conn->real_escape_string($_POST['location'] ?? '');
    $description = $conn->real_escape_string($_POST['description'] ?? '');

    // Mengolah file gambar event
    $eventImage = $_FILES['event_image'] ?? null;
    $imageName = $eventImage['name'];
    $imageTmpName = $eventImage['tmp_name'];
    $imageSize = $eventImage['size'];
    $imageError = $eventImage['error'];

    // Validasi form
    if (empty($eventName) || empty($eventDate) || empty($eventTime) || empty($location) || empty($description) || empty($imageName)) {
        $message = "Semua field harus diisi!";
    } else {
        // Validasi gambar
        $imageExt = strtolower(pathinfo($imageName, PATHINFO_EXTENSION));
        $allowedExt = ['jpg', 'jpeg', 'png'];
        if (!in_array($imageExt, $allowedExt)) {
            $message = "Hanya gambar dengan ekstensi JPG, JPEG, atau PNG yang diperbolehkan.";
        } elseif ($imageSize > 2097152) { // Maksimum 2MB
            $message = "Ukuran gambar maksimal 2MB.";
        } else {
            // Nama file gambar yang unik
            $newImageName = uniqid('', true) . '.' . $imageExt;
            $imageUploadPath = 'uploads/' . $newImageName;

            // Pindahkan file gambar ke folder uploads
            if (move_uploaded_file($imageTmpName, $imageUploadPath)) {
                // Simpan event ke database
                $sql = "INSERT INTO events (event_name, event_date, event_time, location, description, event_image) 
                        VALUES ('$eventName', '$eventDate', '$eventTime', '$location', '$description', '$newImageName')";
                if ($conn->query($sql) === TRUE) {
                    $message = "Event berhasil ditambahkan!";
                } else {
                    $message = "Terjadi kesalahan: " . $conn->error;
                }
            } else {
                $message = "Gagal mengunggah gambar.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Event</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: #dc3545; 
        }
        .navbar-brand, .nav-link {
            color: white !important;
        }
        .navbar-nav .nav-link:hover {
            color: #f8f9fa !important; 
        }
        .btn-primary {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        .btn-primary:hover {
            background-color: #c82333; 
            border-color: #c82333;
        }
        .form-control, .form-control-file, .btn-primary {
            border-color: #dc3545;
        }
        .form-control:focus, .form-control-file:focus {
            border-color: #dc3545;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25); 
        }
        .container h2 {
            color: #dc3545; 
        }
    </style>
</head>
<body>
    <!-- Responsive Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="#">AksiRelawan</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
                <li class="nav-item"><a class="nav-link" href="event.php">Event</a></li>
                <li class="nav-item"><a class="nav-link" href="documentation.php">Event Documentation</a></li>
                <li class="nav-item"><a class="nav-link" href="donasi.php">Donasi</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <h2>Tambah Event Baru</h2>

        <!-- Menampilkan pesan sukses atau error -->
        <?php
        if (isset($message)) {
            echo '<div class="alert alert-' . (strpos($message, 'berhasil') !== false ? 'success' : 'danger') . '">' . $message . '</div>';
        }
        ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="event_name">Nama Event</label>
                <input type="text" class="form-control" id="event_name" name="event_name" required>
            </div>
            <div class="form-group">
                <label for="event_date">Tanggal Event</label>
                <input type="date" class="form-control" id="event_date" name="event_date" required>
            </div>
            <div class="form-group">
                <label for="event_time">Waktu Event</label>
                <input type="time" class="form-control" id="event_time" name="event_time" required>
            </div>
            <div class="form-group">
                <label for="location">Lokasi</label>
                <input type="text" class="form-control" id="location" name="location" required>
            </div>
            <div class="form-group">
                <label for="description">Deskripsi</label>
                <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <label for="event_image">Gambar Event (maks 2MB)</label>
                <input type="file" class="form-control-file" id="event_image" name="event_image" required>
            </div>
            <button type="submit" class="btn btn-primary">Tambah Event</button>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
