<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Dokumentasi Event - Aksi Relawan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        h1 { background-color: #d32f2f; color: #fff; padding: 20px; border-radius: 10px 10px 0 0; }
        .table th { background-color: #d32f2f; color: #fff; }
    </style>
</head>
<body>
<?php
$conn = new mysqli("localhost", "root", "", "aksi_relawan");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$event_id = 1; 
$eventQuery = $conn->query("SELECT * FROM events WHERE id = $event_id");
$event = $eventQuery->fetch_assoc();


$donationQuery = $conn->query("SELECT * FROM donations WHERE event_id = $event_id");
$donations = $donationQuery->fetch_all(MYSQLI_ASSOC);

$totalDonation = 0;
foreach ($donations as $donation) {
    $totalDonation += $donation['jumlah'];
}

$photoQuery = $conn->query("SELECT * FROM photos WHERE event_id = $event_id");
$photos = $photoQuery->fetch_all(MYSQLI_ASSOC);
?>
<div class="container mt-4 p-4 bg-white rounded shadow">
    <h1 class="text-center">Dokumentasi Event: <?= $event['title'] ?></h1>

    <div class="event-details mb-4">
        <h2>Detail Event</h2>
        <p><strong>Tanggal:</strong> <?= $event['date'] ?></p>
        <p><strong>Lokasi:</strong> <?= $event['location'] ?></p>
        <p><strong>Deskripsi:</strong> <?= $event['description'] ?></p>
    </div>

    <div class="event-donation mb-4">
        <h2>Laporan Penggunaan Dana</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Kebutuhan</th>
                    <th>Jumlah (Rp)</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($donations as $donation): ?>
                    <tr>
                        <td><?= $donation['kebutuhan'] ?></td>
                        <td><?= number_format($donation['jumlah'], 0, ',', '.') ?></td>
                    </tr>
                <?php endforeach; ?>

                <tr>
                    <td><strong>Total</strong></td>
                    <td><strong><?= number_format($totalDonation, 0, ',', '.') ?></strong></td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="event-gallery">
        <h2>Dokumentasi Foto</h2>
        <div class="d-flex flex-wrap">
            <?php foreach ($photos as $photo): ?>
                <img src="<?= $photo['photo_path'] ?>" alt="Foto" class="img-fluid m-2" style="max-width: 300px;">
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>
