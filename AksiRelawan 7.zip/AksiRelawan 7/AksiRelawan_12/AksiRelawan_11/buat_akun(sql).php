<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buat Akun - AksiRelawan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="card p-4 shadow-lg" style="width: 400px;">
            <h2 class="text-center mb-4">Buat Akun</h2>
            <?php
                // Koneksi ke database
                $conn = new mysqli("localhost", "root", "", "aksi_relawan");

                // Periksa koneksi
                if ($conn->connect_error) {
                    die("<div class='alert alert-danger'>Koneksi gagal: " . $conn->connect_error . "</div>");
                }

                $message = "";
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $fullName = $conn->real_escape_string($_POST['fullName'] ?? '');
                    $email = $conn->real_escape_string($_POST['email'] ?? '');
                    $username = $conn->real_escape_string($_POST['username'] ?? '');
                    $password = $_POST['password'] ?? '';
                    $confirmPassword = $_POST['confirmPassword'] ?? '';

                    // Validasi form
                    if (empty($fullName) || empty($email) || empty($username) || empty($password) || empty($confirmPassword)) {
                        $message = "Semua field harus diisi!";
                    } elseif ($password !== $confirmPassword) {
                        $message = "Password dan konfirmasi password tidak cocok!";
                    } else {
                        // Simpan password dalam bentuk plain text (tidak di-hash)
                        $plainPassword = $password;

                        // Generate ID menggunakan format teks (misalnya menggunakan kombinasi huruf dan angka)
                        $userId = uniqid("user_", true); // Misalnya ID berbentuk "user_1a2b3c"

                        // Simpan ke database dengan ID berbentuk teks
                        $sql = "INSERT INTO users (user_id, full_name, email, username, password) VALUES ('$userId', '$fullName', '$email', '$username', '$plainPassword')";
                        if ($conn->query($sql) === TRUE) {
                            $message = "Akun berhasil dibuat! Silakan login.";
                        } else {
                            $message = "Terjadi kesalahan: " . $conn->error;
                        }
                    }
                }
            ?>
            <?php if (!empty($message)): ?>
                <div class="alert <?= strpos($message, 'berhasil') !== false ? 'alert-success' : 'alert-danger'; ?>" role="alert">
                    <?= $message; ?>
                </div>
            <?php endif; ?>
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="fullName" class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" id="fullName" name="fullName" placeholder="Masukkan nama lengkap" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan email" required>
                </div>
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" placeholder="Masukkan username" required>
                </div>
                <div class="mb-3 position-relative">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan password" required>
                        <span class="input-group-text" onclick="togglePasswordVisibility('password', this)" style="cursor: pointer;">
                            <i class="bi bi-eye-slash" id="passwordIcon"></i>
                        </span>
                    </div>
                </div>
                <div class="mb-3 position-relative">
                    <label for="confirmPassword" class="form-label">Konfirmasi Password</label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" placeholder="Masukkan ulang password" required>
                        <span class="input-group-text" onclick="togglePasswordVisibility('confirmPassword', this)" style="cursor: pointer;">
                            <i class="bi bi-eye-slash" id="confirmPasswordIcon"></i>
                        </span>
                    </div>
                </div>
                <button type="submit" class="btn btn-danger w-100">Daftar</button>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Fungsi untuk toggle visibility password
        function togglePasswordVisibility(fieldId, iconElement) {
            const inputField = document.getElementById(fieldId);
            const icon = iconElement.querySelector('i');

            if (inputField.type === "password") {
                inputField.type = "text";
                icon.classList.remove('bi-eye-slash');
                icon.classList.add('bi-eye');
            } else {
                inputField.type = "password";
                icon.classList.remove('bi-eye');
                icon.classList.add('bi-eye-slash');
            }
        }
    </script>
</body>
</html>
