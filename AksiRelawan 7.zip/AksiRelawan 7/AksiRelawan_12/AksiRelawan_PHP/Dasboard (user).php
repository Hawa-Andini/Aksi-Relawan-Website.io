<?php 
// Mulai session untuk mengambil informasi pengguna yang sudah login
session_start();

// Cek apakah email ada di session (pengguna sudah login)
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email']; // Ambil email dari session
}

// Koneksi ke database
$mysqli = new mysqli("localhost", "root", "", "aksi_relawan");

// Periksa koneksi
if ($mysqli->connect_error) {
    die("Koneksi gagal: " . $mysqli->connect_error);
}

// Gunakan prepared statement untuk menghindari SQL injection
$stmt = $mysqli->prepare("SELECT * FROM biodata WHERE email = ?");
$stmt->bind_param("s", $email); // Binding parameter email
$stmt->execute();
$result = $stmt->get_result();

// Pastikan hasil query valid dan ada data
if ($result->num_rows > 0) {
    // Data ditemukan
    while ($row = $result->fetch_assoc()) {
        // Tampilkan data event atau lakukan proses lain
        echo "Event: " . $row['nama_event'] . "<br>";
    }
} else {
    echo "Tidak ada event yang ditemukan untuk email tersebut.";
}

// Menutup koneksi
$stmt->close();
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indorelawan Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar">
            <a href="Dashboard (User).html" class="active">Dashboard</a>
            <a href="Dashboard (user) Aktivitas.html">Aktivitas</a>
            <a href="Dashboard (user) Edit Profil.html">Edit Profil</a>
            <a href="Dashboard (user) Aktivitas.html">Donasi</a>
        </div>

        <!-- Main Content -->
        <div class="w-100">
            <!-- Header -->
            <div class="header d-flex justify-content-between">
                <div>
                    <a href="Home Page.html">Home</a>
                    <a href="Event-Halaman Lain.html">Event</a>
                    <a href="Dokumentasi.html">Dokumentasi Event</a>
                    <a href="About Us.html">About Us</a>
                </div>
                <div class="profile-menu dropdown">
                    <a href="#" class="dropdown-toggle text-white" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">R</a>
                    <ul class="dropdown-menu" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item" href="dashboard.html">Dashboard</a></li>
                        <li><a class="dropdown-item" href="#">Home</a></li>
                        <li><a class="dropdown-item" href="#">Edit Profil</a></li>
                        <li><a class="dropdown-item" href="#">Keluar</a></li>
                    </ul>
                </div>
            </div>

            <!-- Content -->
            <div class="container">
                <h1 class="mt-4">Dashboard</h1>

                <!-- Proses Seleksi Relawan -->
                <div class="card">
                    <div class="card-body text-center">
                        <h5 class="card-title">Proses Seleksi Relawan</h5>
                        <p class="card-text">Masih kosong nih! Kamu belum mendaftar ke dalam aktivitas.</p>
                        <a href="#" class="btn btn-danger">Cari Aktivitas</a>
                    </div>
                </div>

                <!-- Riwayat Event yang Didaftarkan -->
                <div class="card mt-4">
                    <div class="card-body">
                        <h5 class="card-title">Riwayat Event yang Didaftarkan</h5>

                        <?php if ($result->num_rows > 0): ?>
                            <ul class="list-group">
                                <?php while ($row = $result->fetch_assoc()): ?>
                                    <li class="list-group-item">
                                        <?php echo $row['nama_event']; ?>
                                    </li>
                                <?php endwhile; ?>
                            </ul>
                        <?php else: ?>
                            <p>Belum ada event yang kamu daftarkan.</p>
                        <?php endif; ?>

                    </div>
                </div>
            </div>

        </div> <!-- End of Main Content -->
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php 
// Menutup koneksi database
$mysqli->close(); 
?>
