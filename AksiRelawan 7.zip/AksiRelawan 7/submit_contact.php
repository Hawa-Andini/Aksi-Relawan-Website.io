<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $telp = $_POST['telp'];
    $pesan = $_POST['pesan'];


    $koneksi = mysqli_connect("localhost", "root", "", "isi_form");
    if (mysqli_connect_error()) {
        die("Koneksi database gagal: " . mysqli_connect_error());
    }

    $aksi = mysqli_query($koneksi, "INSERT INTO contact (id, nama, email, telp, pesan) VALUES ('', '$name', '$email', '$telp','$pesan')");

    if ($aksi) {
        header("Location: Contact Us.php?status=success");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }

    mysqli_close($koneksi);
    exit();
}
?>
