<?php
session_start(); // Start session at the beginning

// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "aksi_relawan");

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
}

// Inisialisasi pesan error dan sukses
$error_message = "";
$success_message = "";

// Verifikasi token dan email
if (isset($_GET['email']) && isset($_GET['token'])) {
    $email = $_GET['email'];
    $token = $_GET['token'];

    // Periksa apakah token valid di database
    $stmt = $conn->prepare("SELECT * FROM password_resets WHERE email = ? AND token = ?");
    $stmt->bind_param("ss", $email, $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Jika token valid, izinkan pengguna untuk reset password
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if (isset($_POST['new_password']) && isset($_POST['confirm_password'])) {
                $new_password = trim($_POST['new_password']);
                $confirm_password = trim($_POST['confirm_password']);

                if ($new_password !== $confirm_password) {
                    $error_message = "Password tidak cocok!";
                } else {
                    // Simpan password baru sebagai plain text di tabel users
                    // Update password di tabel users
                    $update_stmt_users = $conn->prepare("UPDATE users SET new_password = ? WHERE email = ?");
                    $update_stmt_users->bind_param("ss", $new_password, $email);
                    
                    // Simpan password baru juga di tabel password_resets
                    $update_stmt_resets = $conn->prepare("UPDATE password_resets SET new_password = ? WHERE email = ?");
                    $update_stmt_resets->bind_param("ss", $new_password, $email);

                    if ($update_stmt_users->execute() && $update_stmt_resets->execute()) {
                        // Hapus token reset dari tabel password_resets
                        $delete_stmt = $conn->prepare("DELETE FROM password_resets WHERE email = ?");
                        $delete_stmt->bind_param("s", $email);
                        $delete_stmt->execute();

                        $success_message = "Password berhasil diperbarui. Silakan login dengan password baru.";
                    } else {
                        $error_message = "Gagal memperbarui password.";
                    }
                }
            } else {
                // Handle case where new password fields are not set
                $error_message = "Mohon masukkan semua field yang diperlukan.";
            }
        }
    } else {
        $error_message = "Link reset password tidak valid atau sudah kadaluarsa.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="card p-4 shadow-lg" style="width: 400px;">
            <h2 class="text-center mb-4">Reset Password</h2>

            <!-- Menampilkan pesan error jika ada -->
            <?php if ($error_message): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>

            <!-- Menampilkan pesan sukses jika ada -->
            <?php if ($success_message): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo htmlspecialchars($success_message); ?>
                </div>
            <?php endif; ?>

            <!-- Form untuk mengatur password baru -->
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="new_password" class="form-label">Password Baru</label>
                    <div class="input-group">
                        <input type="text" class="form-control" id="new_password" name="new_password" required>
                        <span class="input-group-text" onclick="togglePasswordVisibility('new_password')"><i id="eye-icon-new" class="fas fa-eye"></i></span>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Konfirmasi Password</label>
                    <div class="input-group">
                        <input type="text" class="form-control" id="confirm_password" name="confirm_password" required>
                        <span class="input-group-text" onclick="togglePasswordVisibility('confirm_password')"><i id="eye-icon-confirm" class="fas fa-eye"></i></span>
                    </div>
                </div>
                <button type="submit" class="btn btn-danger w-100 mb-3">Reset Password</button>
                <div class="text-center">
                    <p>Ingat password? <a href="login.php" class="btn btn-link text-danger">Login</a></p>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePasswordVisibility(inputId) {
            var inputField = document.getElementById(inputId);
            var eyeIcon = inputId === 'new_password' ? document.getElementById('eye-icon-new') : document.getElementById('eye-icon-confirm');

            if (inputField.type === "password") {
                inputField.type = "text";
                eyeIcon.classList.remove('fa-eye');
                eyeIcon.classList.add('fa-eye-slash');
            } else {
                inputField.type = "password";
                eyeIcon.classList.remove('fa-eye-slash');
                eyeIcon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
