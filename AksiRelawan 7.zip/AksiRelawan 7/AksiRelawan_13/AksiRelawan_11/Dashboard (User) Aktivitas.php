<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donasi - Indorelawan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar">
            <a href="Dashboard (User).php">Dashboard</a>
            <a href="Dashboard (User) Aktivitas.php"class="active">Aktivitas</a>
            <a href="Dashboard (User) Edit Profil.php">Edit Profil</a>
            <a href="Dashboard (User) Donasi.php">Donasi</a>
        </div>

        <!-- Main Content -->
        <div class="w-100">
            <!-- Header -->
            <div class="header d-flex justify-content-between align-items-center">
                <div>
                    <a href="HomePage.php">Home</a>
                    <a href="Event-Halaman Lain.php">Event</a>
                    <a href="Dokumentasi.php">Dokumentasi Event</a>
                    <a href="Contact Us.php">Contact Us</a>
                </div>
                <div class="profile-menu dropdown">
                    <a href="#" class="dropdown-toggle text-white" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">R</a>
                    <ul class="dropdown-menu" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item" href="Dashboard (User).php">Dashboard</a></li>
                        <li><a class="dropdown-item" href="HomePage.php">Home</a></li>
                        <li><a class="dropdown-item" href="#">Lihat Profil</a></li>
                        <li><a class="dropdown-item" href="#">Keluar</a></li>
                    </ul>
                </div>
            </div>

      <!-- Main Content -->
      <div class="container">
        <h2>Aktivitas (0)</h2>
        <div class="d-flex justify-content-between mb-4">
          <input type="text" class="form-control w-50" placeholder="Judul Aktivitas">
          <select class="form-select w-25">
            <option selected>Terbaru</option>
            <option value="1">Terlama</option>
          </select>
          <select class="form-select w-25">
            <option selected>Semua</option>
            <option value="1">Aktif</option>
            <option value="2">Selesai</option>
          </select>
        </div>
        <div class="text-center py-5">
          <i class="fa-light fa-file-circle-xmark fa-4x" alt="Kosong" class="mb-3"></i>
          <p>Masih kosong nih<br>Anda belum terdaftar di aktivitas manapun</p>
          <a href="Event-Halaman Lain.php" class="btn btn-danger">Cari aktivitas</a>
        </div>
      </div>
    </div>
  </div>

    <!-- Include Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
