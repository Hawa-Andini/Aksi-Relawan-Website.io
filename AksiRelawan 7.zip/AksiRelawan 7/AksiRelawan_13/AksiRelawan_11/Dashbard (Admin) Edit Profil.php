<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indorelawan Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar">
            <a href="Dashboard (Admin).php">Dashboard</a>
            <a href="Dashbard (Admin) Edit Profil.php" class="active">Edit Profil</a>
            <a href="Dashboard (Admin) Tambah Event.php">Tambah Event</a>
            <a href="Dashboard (Admin) Tambah Dok.php">Tambah Dokumentasi</a>
        </div>

        <!-- Main Content -->
        <div class="w-100">
            <!-- Header -->
            <div class="header d-flex justify-content-between">
                <div>
                    <a href="HomePage.php">Home</a>
                    <a href="Event-Halaman Lain.php">Event</a>
                    <a href="Dokumentasi.php">Dokumentasi Event</a>
                    <a href="Contact Us.php">Contact Us</a>
                </div>
                <div class="profile-menu dropdown">
                    <a href="#" class="dropdown-toggle text-white" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">R</a>
                    <ul class="dropdown-menu" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item" href="Dashboard (Admin).php">Dashboard</a></li>
                        <li><a class="dropdown-item" href="#">Lihat Profil</a></li>
                        <li><a class="dropdown-item" href="#">Keluar</a></li>
                    </ul>
                </div>
            </div>

            <!-- Content -->
            <div class="container mt-4">
              <h1>Edit Profil</h1>
              <!-- Tabs Navigation -->
              <ul class="nav nav-tabs" id="editProfileTabs" role="tablist">
                  <li class="nav-item" role="presentation">
                      <button class="nav-link active" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="true">
                          Profil
                      </button>
                  </li>
                  <li class="nav-item" role="presentation">
                      <button class="nav-link" id="security-tab" data-bs-toggle="tab" data-bs-target="#security" type="button" role="tab" aria-controls="security" aria-selected="false">
                          Keamanan
                      </button>
                  </li>
              </ul>

              <!-- Tabs Content -->
              <div class="tab-content" id="editProfileTabsContent">
                  <!-- Profil Tab -->
                  <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                      <div class="card mt-3">
                          <div class="card-body">
                              <form>
                                  <div class="mb-3">
                                      <label for="avatar" class="form-label">Avatar</label>
                                      <input type="file" class="form-control" id="avatar">
                                  </div>
                                  <div class="mb-3">
                                      <label for="name" class="form-label">Nama</label>
                                      <input type="text" class="form-control" id="name" placeholder="Nama">
                                  </div>
                                  <div class="mb-3">
                                      <label for="email" class="form-label">Email</label>
                                      <input type="email" class="form-control" id="email" placeholder="Email">
                                  </div>
                                  <div class="mb-3">
                                      <label for="gender" class="form-label">Jenis Kelamin</label>
                                      <select class="form-select" id="gender">
                                          <option value="male">Laki-Laki</option>
                                          <option value="female">Perempuan</option>
                                      </select>
                                  </div>
                                  <button type="submit" class="btn btn-primary">Simpan</button>
                              </form>
                          </div>
                      </div>
                  </div>

                  <!-- Keamanan Tab -->
                  <div class="tab-pane fade" id="security" role="tabpanel" aria-labelledby="security-tab">
                      <div class="card mt-3">
                          <div class="card-body">
                              <h5>Keamanan Akun</h5>
                              <form>
                                  <div class="mb-3">
                                      <label for="current-password" class="form-label">Password Saat Ini</label>
                                      <input type="password" class="form-control" id="current-password" placeholder="Password Saat Ini">
                                  </div>
                                  <div class="mb-3">
                                      <label for="new-password" class="form-label">Password Baru</label>
                                      <input type="password" class="form-control" id="new-password" placeholder="Password Baru">
                                  </div>
                                  <div class="mb-3">
                                      <label for="confirm-password" class="form-label">Konfirmasi Password Baru</label>
                                      <input type="password" class="form-control" id="confirm-password" placeholder="Konfirmasi Password Baru">
                                  </div>
                                  <button type="submit" class="btn btn-primary">Ubah Password</button>
                              </form>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
