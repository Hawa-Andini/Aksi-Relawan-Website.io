<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indorelawan Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar">
            <a href="Dashboard (Admin).php" class="active">Dashboard</a>
            <a href="Dashbard (Admin) Edit Profil.php">Edit Profil</a>
            <a href="Dashboard (Admin) Tambah Event.php">Tambah Event</a>
            <a href="Dashboard (Admin) Tambah Dok.php">Tambah Dokumentasi</a>
        </div>

        <!-- Main Content -->
        <div class="w-100">
            <!-- Header -->
            <div class="header d-flex justify-content-between">
                <div>
                    <a href="HomePage.php">Home</a>
                    <a href="Event-Halaman Lain.php">Event</a>
                    <a href="Dokumentasi.php">Dokumentasi Event</a>
                    <a href="Contact Us.php">Contact Us</a>
                </div>
                <div class="profile-menu dropdown">
                    <a href="#" class="dropdown-toggle text-white" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">R</a>
                    <ul class="dropdown-menu" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item" href="Dashboard (Admin).php">Dashboard</a></li>
                        <li><a class="dropdown-item" href="#">Lihat Profil</a></li>
                        <li><a class="dropdown-item" href="#">Keluar</a></li>
                    </ul>
                </div>
            </div>

            <!-- Content -->
            <div class="container">
                <h1 class="mt-4">Dashboard</h1>

                <!-- Proses Seleksi Relawan -->
                <div class="card">
                    <div class="card-body text-center">
                        <h5 class="card-title">Proses Seleksi Relawan</h5>
                        <p class="card-text">Berikut daftar user yang melamar menjadi relawan.</p>
                        <a href="#" class="btn btn-danger">Lihat Daftar Relawan</a>
                    </div>
                </div>
            </div>

      <!-- Main Content -->
      <div class="container">
        <div class="row">
        <!-- Rangkuman -->
        <div class="col-md-4">
            <div class="card">
              <div class="card-body text-center">
                <img src="https://via.placeholder.com/80" class="rounded-circle mb-3" alt="Profile">
                <h5 class="card-title">Anjani Putri</h5>
                <a href="#" class="btn btn-link">EditS Profil</a>
                <hr>
                <p>Total Jam Kerja: <b>0</b></p>
              </div>
            </div>
        </div>
        <!-- Pesan Masuk -->
          <div class="col-md-4">
            <div class="card">
              <div class="card-body text-center">
                <h5 class="card-title d-flex justify-content-between">Pesan Masuk</h5>
                <div class="text-center py-3">
                  <img src="https://via.placeholder.com/80" alt="Pesan Kosong" class="mb-3">
                  <p>Belum ada pesan masuk</p>
                  <small>Nantinya, pesan dari organisasi akan masuk ke sini.</small>
                </div>
              </div>
            </div>
          </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
