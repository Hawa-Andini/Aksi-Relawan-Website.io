<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donasi - Indorelawan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
<div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar">
            <a href="Dashboard (User).php">Dashboard</a>
            <a href="Dashboard (User) Aktivitas.php">Aktivitas</a>
            <a href="Dashboard (User) Edit Profil.php">Edit Profil</a>
            <a href="Dashboard (User) Donasi.php" class="active">Donasi</a>
        </div>

        <!-- Main Content -->
        <div class="w-100">
            <!-- Header -->
            <div class="header d-flex justify-content-between align-items-center">
                <div>
                    <a href="HomePage.php">Home</a>
                    <a href="Event-Halaman Lain.php">Event</a>
                    <a href="Dokumentasi.php">Dokumentasi Event</a>
                    <a href="Contact Us.php">Contact Us</a>
                </div>
                <div class="profile-menu dropdown">
                    <a href="#" class="dropdown-toggle text-white" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">R</a>
                    <ul class="dropdown-menu" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item" href="Dashboard (User).php">Dashboard</a></li>
                        <li><a class="dropdown-item" href="HomePage.php">Home</a></li>
                        <li><a class="dropdown-item" href="#">Lihat Profil</a></li>
                        <li><a class="dropdown-item" href="#">Keluar</a></li>
                    </ul>
                </div>
            </div>

            <!-- Content -->
            <div class="container mt-4">
                <h1>Donasi</h1>
                <div class="row">
                    <!-- Total Donasi -->
                    <div class="col-md-8">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Total Donasi</h5>
                                <h3 class="card-text">Rp. 0.00</h3>
                            </div>
                        </div>
                    </div>
                    <!-- Informasi Donasi -->
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-body text-center">
                                <p>Donasi kamu sangat berarti dan memberikan dampak positif yang besar</p>
                                <a href="#" class="btn btn-danger">Donasi Sekarang</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Riwayat Donasi -->
                <h5>Riwayat Donasi</h5>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <button class="btn btn-outline-secondary btn-sm">Semua Donasi</button>
                        <button class="btn btn-outline-secondary btn-sm">Donasi Sukses</button>
                        <button class="btn btn-outline-secondary btn-sm">Donasi Gagal</button>
                        <button class="btn btn-outline-secondary btn-sm">Menunggu Pembayaran</button>
                    </div>
                    <div>
                        <input type="date" class="form-control form-control-sm d-inline" style="width: auto;" placeholder="Start date">
                        <span class="mx-2">-</span>
                        <input type="date" class="form-control form-control-sm d-inline" style="width: auto;" placeholder="End date">
                    </div>
                </div>

                <!-- Tabel Riwayat Donasi -->
                <table class="table table-bordered text-center">
                    <thead class="table-light">
                        <tr>
                            <th>Tujuan Donasi</th>
                            <th>Jumlah</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="4">
                                <i class="fa-light fa-file-circle-xmark fa-4x" alt="Kosong" class="mb-3"></i>
                                <p>No data</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Include Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
