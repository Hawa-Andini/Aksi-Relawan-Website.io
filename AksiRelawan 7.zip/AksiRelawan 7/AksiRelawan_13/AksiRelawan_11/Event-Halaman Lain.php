<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Berita</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: red;
            color: white;
            padding: 1rem;
            text-align: center;
        }
        .container-1 {
            padding: 2rem;
            text-align: center;
        }
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 1rem;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
        .jumbotron {
            background-image: url('images/Volunteer.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7); /* Efek bayangan pada teks agar lebih jelas */
            padding: 100px 0;
        }
        .card-img-top {
            width: 400px;
            height: 200px;
            object-fit: cover;
            object-position: center;
        }
        /* CSS untuk efek hover */
        .news-card {
            width: 100%;
            height: 350px;
            position: relative;
            overflow: hidden;
            transition: transform 0.3s;
        }
        .news-card:hover {
            transform: scale(1.05);
        }
        .news-card img {
            transition: transform 0.3s ease;
        }
        .news-card:hover img {
            transform: scale(1.1);
        }

        /* CSS untuk overlay saat hover */
        .news-card .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6); /* Warna overlay hitam transparan */
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
            font-size: 1.5em;
            font-weight: bold;
        }
        .news-card:hover .overlay {
            opacity: 1;
        }
    </style>
</head>
<body>
    <header class="bg-danger text-white text-center py-3">
        <h1>Aksi Relawan</h1>
        <p>Bersama Membangun Negeri dengan Aksi Nyata</p>
    </header>

    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="logo.png" alt="Avatar Logo" style="width:40px;" class="rounded-pill"> 
              </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav mx-auto ">
              <li class="nav-item">
                <a class="nav-link" href="HomePage.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#event">Event</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Donasi.html">Donasi</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Dokumentasi.php">Dokumentasi Event</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Contact Us.php">Contact Us</a>
              </li>
            </ul>
            <form class="d-flex">
              <input class="form-control me-2" type="text" placeholder="Search">
              <button class="btn btn-danger" type="button">Search</button>
            </form>
          </div>
        </div>
    </nav>
    <!-- Jumbotron -->
    <div class="jumbotron text-center">
        <h1>Daftar Event</h1>
        <p>Event yang akan dilaksanakan oleh kami!</p>
    </div>

    <!-- Konten Utama -->
    <div class="container">
        <div class="row">
            <!-- Card untuk setiap berita -->
            <div class="col-md-4">
                <a href="Event-Relawan Peduli Lansia.html" class="text-decoration-none text-dark">
                    <div class="card news-card mb-4">
                        <img src="images/event-lansia.jpg" class="card-img-top" alt="Gambar Berita 1">
                        <div class="overlay">Baca Selengkapnya</div>
                        <div class="card-body">
                            <h5 class="card-title">Relawan Peduli Lansia</h5>
                            <span class="badge bg-success">Sosial</span>
                            <span class="badge bg-danger">Lansia</span>
                                <p class="text-muted mt-2">
                                    <i class="fa fa-calendar"></i> 2 November 2024<br>
                                    <i class="fa fa-map-marker-alt"></i> Gayungan, Wonokromo, Surabaya
                                </p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="Event-Go Green.html" class="text-decoration-none text-dark">
                    <div class="card news-card mb-4">
                        <img src="images/event-gogreen.jpg" class="card-img-top" alt="Gambar Berita 2">
                        <div class="overlay">Baca Selengkapnya</div>
                        <div class="card-body">
                            <h5 class="card-title">Go Green - Menanam Pohon</h5>
                            <span class="badge bg-success">Lingkungan</span>
                            <span class="badge bg-danger">Umum</span>
                                <p class="text-muted mt-2">
                                    <i class="fa fa-calendar"></i> 12 November 2024<br>
                                    <i class="fa fa-map-marker-alt"></i> Ketintang, Wonokromo, Surabaya
                                </p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="Event-Berbagi dengan Sahabat Kecil.html" class="text-decoration-none text-dark">
                    <div class="card news-card mb-4">
                        <img src="images/event-panti.jpg" class="card-img-top" alt="Gambar Berita 3">
                        <div class="overlay">Baca Selengkapnya</div>
                        <div class="card-body">
                            <h5 class="card-title">Berbagi dengan Sahabat Kecil</h5>
                            <span class="badge bg-success">Sosial</span>
                            <span class="badge bg-danger">Anak</span>
                                <p class="text-muted mt-2">
                                    <i class="fa fa-calendar"></i> 25 November 2024<br>
                                    <i class="fa fa-map-marker-alt"></i> Karah, Wonokromo, Surabaya
                                </p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="halaman-berita3.html" class="text-decoration-none text-dark">
                    <div class="card news-card mb-4">
                        <img src="images/Mental.jpeg" class="card-img-top" alt="Gambar Berita 3">
                        <div class="overlay">Baca Selengkapnya</div>
                        <div class="card-body">
                            <h5 class="card-title">Mengajar Mental Health</h5>
                            <span class="badge bg-success">Mental</span>
                            <span class="badge bg-danger">Remaja</span>
                                <p class="text-muted mt-2">
                                    <i class="fa fa-calendar"></i> 5 Desember 2024<br>
                                    <i class="fa fa-map-marker-alt"></i> Gayungan, Wonokromo, Surabaya
                                </p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="halaman-berita3.html" class="text-decoration-none text-dark">
                    <div class="card news-card mb-4">
                        <img src="images/susu.jpeg" class="card-img-top" alt="Gambar Berita 3">
                        <div class="overlay">Baca Selengkapnya</div>
                        <div class="card-body">
                            <h5 class="card-title">Belajar Mtk dan Berbagi Susu</h5>
                            <span class="badge bg-success">Edukasi</span>
                            <span class="badge bg-danger">Anak</span>
                              <p class="text-muted mt-2">
                                <i class="fa fa-calendar"></i> 15 Desember 2024<br>
                                <i class="fa fa-map-marker-alt"></i> Ketintang Baru, Wonokromo, Surabaya
                              </p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <!-- Script Bootstrap JavaScript dan jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
