<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $alamat = $_POST['alamat'];
    $telp = $_POST['telp'];
    $pwd = $_POST['pwd'];
    $pwdConfirm = $_POST['pwdConfirm'];

    if ($pwd !== $pwdConfirm) {
        header("Location: Pendaftaran Relawan.php?status=error_password");
        exit;
    }

    $target_dir = "uploads/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true); 
    }

    $file = $_FILES["cv"];
    $fileName = basename((string)$file["name"]);
    $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $fileSize = $file["size"];
    $fileTmpPath = $file["tmp_name"];
    $target_file = $target_dir . time() . "_" . $fileName; 

    if ($fileType != "pdf") {
        header("Location: Pendaftaran Relawan.php?status=error_filetype");
        exit;
    }

    if ($fileSize > 2 * 1024 * 1024) {
        header("Location: Pendaftaran Relawan.php?status=error_filesize");
        exit;
    }

    if (!move_uploaded_file($fileTmpPath, $target_file)) {
        header("Location: Pendaftaran Relawan.php?status=error_upload");
        exit;
    }

    $koneksi = mysqli_connect("localhost", "root", "", "isi_form");
    if (mysqli_connect_error()) {
        die("Koneksi database gagal: " . mysqli_connect_error());
    }

    $aksi = mysqli_query($koneksi, "INSERT INTO biodata (id, nama, email, alamat, telp, pwd, cv) VALUES ('', '$nama', '$email', '$alamat', '$telp', '$pwd', '$target_file')");

    if ($aksi) {
        header("Location: Pendaftaran Relawan.php?status=success");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }

    mysqli_close($koneksi);
}
?>